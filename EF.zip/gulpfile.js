const gulp = require('gulp');
const sass = require('gulp-sass');
const browserSync = require('browser-sync').create();
const autoprefixer = require('gulp-autoprefixer');

var del = require('del');
var sourcemaps = require('gulp-sourcemaps');


//compile scss into css

// remove old css
gulp.task('clean', () => {
    return del([
        'css/*.css',
    ]);
});




gulp.task('styles', () => {
    return gulp.src('scss/**/*.scss')
        .pipe(sourcemaps.init())
        .pipe(sass.sync({ outputStyle: 'compressed' }).on('error', sass.logError))
        .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('css/'))
        .pipe(browserSync.stream());
});

gulp.task('watch', () => {

    browserSync.init({
        server: {
            baseDir: "./",
            index: "/index.html"
        }
    });

    gulp.watch('./scss/**/*.scss', (done) => {
        gulp.series(['clean', 'styles'])(done);
    });
    gulp.watch('./templates/*.html').on('change', browserSync.reload);
    gulp.watch('./js/**/*.js').on('change', browserSync.reload);
});


gulp.task('default', gulp.series(['clean', 'styles', 'watch']));