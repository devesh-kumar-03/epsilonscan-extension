$(document).ready(function() {

    // menu JS start
    // menu JS end















    // $('#burger-control ').click(function() {
    //   $("#nav-icon").toggleClass('open');
    //   $("#burger-menu .bg").toggle();
    //   $(".menu-slide-bar").delay(8000).toggleClass("slide-open");
    // });

    // $('#burger-menu .bg').click(function() {
    //   $("#nav-icon").toggleClass('open');
    //   $("#burger-menu").toggle();
    // });


    $(".filter a").click(function() {
        $(".filter a").removeClass("active");
        $(this).addClass("active");
    })



    if ($(window).width() > 992) {



        //mega menu hover code for all sites
        $("#mega-menu li").focusin(function() {
            $("#mega-menu li").removeClass("focus");
            $(this).addClass("focus");
        });

        $("#mega-menu li").hover(function() {
            $(this).addClass("focus");
        });

        $("#mega-menu li").mouseout(function() {
            $(this).removeClass("focus");
        });


        $("#mega-menu li .child-menu").focusin(function() {
            $(this).parent("li").addClass("focus");
        });

        $("#mega-menu li .child-menu").focusout(function() {
            $(this).parent("li").removeClass("focus");
        });

        $(document).click(function() {
            $("#mega-menu li").removeClass("focus");

        });





    }

    if ($(window).width() < 992) {

        $('#mega-menu').insertAfter('.menu-slide-bar .logo');

        $("#mega-menu").addClass("accordion");

        $(".parent-link a").click(function() {
            $(this).next(".child-menu").slideToggle();
            $(this).parent(".parent-link").toggleClass('active');


        });

    } else {
        $('#mega-menu').insertAfter('.center-section .info');
        $("#mega-menu").removeClass("accordion");
    }






    //$('#mega-menu').appendTo('');


    // other page js

    $('.books-slider').owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        //responsiveClass: true,
        responsive: {
            320: {
                items: 1,
                nav: true,
                loop: true
            },
            768: {
                items: 3,
                nav: true,
                loop: true
            },
            1200: {
                items: 5,
                nav: true,
                loop: true
            }
        }
    });


    $('.video-slider').owlCarousel({
        loop: true,
        margin: 40,
        nav: true,
        //responsiveClass: true,
        responsive: {
            320: {
                items: 1,
                nav: true,
                loop: true
            },
            768: {
                items: 2,
                nav: true,
                loop: true
            },
            1200: {
                items: 3,
                nav: true,
                loop: true
            }
        }
    });



    $(".search-input").on('input', function() {
        $(".clear-input").show();
    });


    $(".clear-input").click(function() {
        $(".search-input").val('');
        $(this).hide();
    });




    // $(document).on("click", ".share a", function() {
    //     $(this).each(function() {
    //         $(this).click(function() {
    //             // var title = $(this).closest('.content-details').children(".title").text();
    //             // var url = $(this).closest('.content-details').find('.link a').attr('href');
    //             // var facebook = "https://www.facebook.com/sharer.php?u=" + url;
    //             // var twitter = "https://twitter.com/share?url=" + url + "&text=" + title;
    //             // var linkedin = "https://www.linkedin.com/shareArticle?mini=true&url=" + url;
    //             // $("#share-facebook a").attr("href", facebook);
    //             // $("#share-twitter a").attr("href", twitter);
    //             // $("#share-linkedin a").attr("href", linkedin);
    //             // $("#copylink").html(url);
    //             $(".model-share-bg").show();
    //         })
    //     });
    // });

    $(".share a").each(function() {
        $(this).click(function() {
            $(".model-share-bg").show();
        })
    });

    $(".close-model").click(function() {
        $(".model-share-bg").hide();

    });

    $(".model-share-bg").click(function() {
        $(".model-share-bg").hide();

    });

    $(document).on('keydown', function(e) {
        if (e.keyCode === 27) {
            $(".model-share-bg").hide();
        }
    });

    var button = document.getElementById("copy-button");

    button.addEventListener("click", function(event) {
        event.preventDefault();
        var input = document.getElementById("copylink");
        input.select();
        document.execCommand("copy");
    });

});
