$(document).ready(function() {

  // menu JS start
  // menu JS end















  // $('#burger-control ').click(function() {
  //   $("#nav-icon").toggleClass('open');
  //   $("#burger-menu .bg").toggle();
  //   $(".menu-slide-bar").delay(8000).toggleClass("slide-open");
  // });

  // $('#burger-menu .bg').click(function() {
  //   $("#nav-icon").toggleClass('open');
  //   $("#burger-menu").toggle();
  // });


  $(".filter a").click(function() {
    $(".filter a").removeClass("active");
    $(this).addClass("active");
  })



  if ($(window).width() > 992) {



    //mega menu hover code for all sites
    $("#mega-menu li").focusin(function() {
      $("#mega-menu li").removeClass("focus");
      $(this).addClass("focus");
    });

    $("#mega-menu li").hover(function() {
      $(this).addClass("focus");
    });

    $("#mega-menu li").mouseout(function() {
      $(this).removeClass("focus");
    });


    $("#mega-menu li .child-menu").focusin(function() {
      $(this).parent("li").addClass("focus");
    });

    $("#mega-menu li .child-menu").focusout(function() {
      $(this).parent("li").removeClass("focus");
    });

    $(document).click(function() {
      $("#mega-menu li").removeClass("focus");

    });





  }

  if ($(window).width() < 992) {

    $('#mega-menu').insertAfter('.menu-slide-bar .logo');

    $("#mega-menu").addClass("accordion");

    $(".parent-link a").click(function() {
      $(this).next(".child-menu").slideToggle();
      $(this).parent(".parent-link").toggleClass('active');


    });

  } else {
    $('#mega-menu').insertAfter('.center-section .info');
    $("#mega-menu").removeClass("accordion");
  }






  //$('#mega-menu').appendTo('');


  // other page js

  $('.books-slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    //responsiveClass: true,
    responsive: {
      320: {
        items: 1,
        nav: true,
        loop: true
      },
      768: {
        items: 3,
        nav: true,
        loop: true
      },
      1200: {
        items: 5,
        nav: true,
        loop: true
      }
    }
  });


  $('.video-slider').owlCarousel({
    loop: true,
    margin: 40,
    nav: true,
    //responsiveClass: true,
    responsive: {
      320: {
        items: 1,
        nav: true,
        loop: true
      },
      768: {
        items: 2,
        nav: true,
        loop: true
      },
      1200: {
        items: 3,
        nav: true,
        loop: true
      }
    }
  });



  $(".search-input").on('input', function() {
    $(".clear-input").show();
  });


  $(".clear-input").click(function() {
    $(".search-input").val('');
    $(this).hide();
  });




  // $(document).on("click", ".share a", function() {
  //     $(this).each(function() {
  //         $(this).click(function() {
  //             // var title = $(this).closest('.content-details').children(".title").text();
  //             // var url = $(this).closest('.content-details').find('.link a').attr('href');
  //             // var facebook = "https://www.facebook.com/sharer.php?u=" + url;
  //             // var twitter = "https://twitter.com/share?url=" + url + "&text=" + title;
  //             // var linkedin = "https://www.linkedin.com/shareArticle?mini=true&url=" + url;
  //             // $("#share-facebook a").attr("href", facebook);
  //             // $("#share-twitter a").attr("href", twitter);
  //             // $("#share-linkedin a").attr("href", linkedin);
  //             // $("#copylink").html(url);
  //             $(".model-share-bg").show();
  //         })
  //     });
  // });

  $(".share a").each(function() {
    $(this).click(function() {
      $(".model-share-bg").show();
    })
  });

  $(".close-model").click(function() {
    $(".model-share-bg").hide();

  });

  $(".model-share-bg").click(function() {
    $(".model-share-bg").hide();

  });

  $(document).on('keydown', function(e) {
    if (e.keyCode === 27) {
      $(".model-share-bg").hide();
    }
  });

  var button = document.getElementById("copy-button");

  button.addEventListener("click", function(event) {
    event.preventDefault();
    var input = document.getElementById("copylink");
    input.select();
    document.execCommand("copy");
  });

});


// ------- video overlay filter start
/*
 *  gridder - v1.4.2
 *  A jQuery plugin that displays a thumbnail grid expanding preview similar to the effect seen on Google Images.
 *  http://www.oriongunning.com/
 *
 *  Made by Orion Gunning
 *  Under MIT License
 */
(function(factory) {
  if (typeof define === "function" && define.amd) {
    // AMD. Register as an anonymous module depending on jQuery.
    define(["jquery"], factory);
  } else if (typeof exports === "object") {
    // Node/CommonJS
    module.exports = factory(require("jquery"));
  } else {
    // No AMD. Register plugin with global jQuery object.
    factory(jQuery);
  }
})(function($) {

  /* Custom Easing */
  $.fn.extend($.easing, {
    def: "easeInOutExpo",
    easeInOutExpo: function(e, f, a, h, g) { if (f === 0) { return a; } if (f === g) { return a + h; } if ((f /= g / 2) < 1) { return h / 2 * Math.pow(2, 10 * (f - 1)) + a; } return h / 2 * (-Math.pow(2, -10 * --f) + 2) + a; }
  });

  /* KEYPRESS LEFT & RIGHT ARROW */
  /* This will work only if a current gridder is opened. */
  $(document).keydown(function(e) {
    var keycode = e.keyCode;
    var $current_gridder = $(".currentGridder");
    var $current_target = $current_gridder.find(".gridder-show");
    if ($current_gridder.length) {
      if (keycode === 37) {
        //console.log("Pressed Left Arrow");
        $current_target.prev().prev().trigger("click");
        e.preventDefault();
      }
      if (keycode === 39) {
        //console.log("Pressed Right Arrow");
        $current_target.next().trigger("click");
        e.preventDefault();
      }
    } else {
      //console.log("No active gridder.");
    }
  });

  $.fn.gridderExpander = function(options) {

    /* GET DEFAULT OPTIONS OR USE THE ONE PASSED IN THE FUNCTION  */
    var settings = $.extend({}, $.fn.gridderExpander.defaults, options);

    return this.each(function() {

      var mybloc;
      var _this = $(this);
      var visible = false;

      // START CALLBACK
      settings.onStart(_this);

      // CLOSE FUNCTION
      function closeExpander(base) {

        // SCROLL TO CORRECT POSITION FIRST
        if (settings.scroll) {
          $("html, body").animate({
            scrollTop: base.find(".selectedItem").offset().top - settings.scrollOffset
          }, {
            duration: 200,
            easing: settings.animationEasing
          });
        }

        _this.removeClass("hasSelectedItem");

        // REMOVES GRIDDER EXPAND AREA
        visible = false;
        base.find(".selectedItem").removeClass("selectedItem");

        base.find(".gridder-show").slideUp(settings.animationSpeed, settings.animationEasing, function() {
          base.find(".gridder-show").remove();
          settings.onClosed(base);
        });

        /* REMOVE CURRENT ACTIVE GRIDDER */
        $(".currentGridder").removeClass("currentGridder");
      }

      // OPEN EXPANDER
      function openExpander(myself) {

        /* CURRENT ACTIVE GRIDDER */
        $(".currentGridder").removeClass("currentGridder");
        _this.addClass("currentGridder");

        /* ENSURES THE CORRECT BLOC IS ACTIVE */
        if (!myself.hasClass("selectedItem")) {
          _this.find(".selectedItem").removeClass("selectedItem");
          myself.addClass("selectedItem");
        } else {
          // THE SAME IS ALREADY OPEN, LET"S CLOSE IT
          closeExpander(_this, settings);
          return;
        }

        /* REMOVES PREVIOUS BLOC */
        _this.find(".gridder-show").remove();


        /* ADD CLASS TO THE GRIDDER CONTAINER
         * So you can apply global style when item selected.
         */
        if (!_this.hasClass("hasSelectedItem")) {
          _this.addClass("hasSelectedItem");
        }

        /* ADD LOADING BLOC */
        var $htmlcontent = $("<div class=\"gridder-show loading\"></div>");
        mybloc = $htmlcontent.insertAfter(myself);

        /* GET CONTENT VIA AJAX OR #ID*/
        var thecontent = "";

        if (myself.data("griddercontent").indexOf("#") === 0) {

          // Load #ID Content
          thecontent = $(myself.data("griddercontent")).html();
          processContent(myself, thecontent);
        } else {

          // Load AJAX Content
          $.ajax({
            type: "GET",
            url: myself.data("griddercontent"),
            success: function(data) {
              thecontent = data;
              processContent(myself, thecontent);
            },
            error: function(request) {
              thecontent = request.responseText;
              processContent(myself, thecontent);
            }
          });
        }
      }

      // PROCESS CONTENT
      function processContent(myself, thecontent) {

        /* FORMAT OUTPUT */
        var htmlcontent = "<div class=\"gridder-padding\">";

        if (settings.showNav) {

          /* CHECK IF PREV AND NEXT BUTTON HAVE ITEMS */
          var prevItem = ($(".selectedItem").prev());
          var nextItem = ($(".selectedItem").next().next());

          htmlcontent += "<div class=\"gridder-navigation\">";
          htmlcontent += "<a href=\"#\" class=\"gridder-close\">" + settings.closeText + "</a>";
          htmlcontent += "<a href=\"#\" class=\"gridder-nav prev " + (!prevItem.length ? "disabled" : "") + "\">" + settings.prevText + "</a>";
          htmlcontent += "<a href=\"#\" class=\"gridder-nav next " + (!nextItem.length ? "disabled" : "") + "\">" + settings.nextText + "</a>";
          htmlcontent += "</div>";
        }

        htmlcontent += "<div class=\"gridder-expanded-content\">";
        htmlcontent += thecontent;
        htmlcontent += "</div>";
        htmlcontent += "</div>";

        // IF EXPANDER IS ALREADY EXPANDED
        if (!visible) {
          mybloc.hide().append(htmlcontent).slideDown(settings.animationSpeed, settings.animationEasing, function() {
            visible = true;
            /* AFTER EXPAND CALLBACK */
            if (typeof(settings.onContent) === "function") {
              settings.onContent(mybloc);
            }
          });
        } else {
          mybloc.html(htmlcontent);
          mybloc.find(".gridder-padding").fadeIn(settings.animationSpeed, settings.animationEasing, function() {
            visible = true;
            /* CHANGED CALLBACK */
            if (typeof(settings.onContent) === "function") {
              settings.onContent(mybloc);
            }
          });
        }

        /* SCROLL TO CORRECT POSITION AFTER */
        if (settings.scroll) {
          var offset = (settings.scrollTo === "panel" ? myself.offset().top + myself.height() - settings.scrollOffset : myself.offset().top - settings.scrollOffset);
          $("html, body").animate({
            scrollTop: offset
          }, {
            duration: settings.animationSpeed,
            easing: settings.animationEasing
          });
        }

        /* REMOVE LOADING CLASS */
        mybloc.removeClass("loading");
      }

      /* CLICK EVENT */
      _this.on("click", ".gridder-list .video .pic", function(e) {
        e.preventDefault();

        var myself = $(this).parents(".gridder-list");
        openExpander(myself);


      });

      /* NEXT BUTTON */
      _this.on("click", ".gridder-nav.next", function(e) {
        e.preventDefault();
        $(this).parents(".gridder-show").next().trigger("click");
      });

      /* PREVIOUS BUTTON */
      _this.on("click", ".gridder-nav.prev", function(e) {
        e.preventDefault();
        $(this).parents(".gridder-show").prev().prev().trigger("click");
      });

      /* CLOSE BUTTON */
      _this.on("click", ".gridder-close", function(e) {
        e.preventDefault();
        closeExpander(_this);
      });
    });
  };

  // Default Options
  $.fn.gridderExpander.defaults = {
    scroll: true,
    scrollOffset: 30,
    scrollTo: "panel", // panel or listitem
    animationSpeed: 400,
    animationEasing: "easeInOutExpo",
    showNav: true,
    nextText: "Next",
    prevText: "Previous",
    closeText: "Close",
    onStart: function() {},
    onContent: function() {},
    onClosed: function() {}
  };

});



$(document).ready(function($) {

  // REMOVE AND ADD CLICK EVENT
  $('.doAddItem').on('click', function() {
    $(".gridder").data('gridderExpander').gridderAddItem('TEST');
  });

  // Call Gridder
  $(".gridder").gridderExpander({
    scrollOffset: 60,
    scrollTo: "panel", // "panel" or "listitem"
    animationSpeed: 400,
    animationEasing: "easeInOutExpo",
    onStart: function() {
      //console.log("Gridder Inititialized");
    },
    onExpanded: function(object) {
      // console.log("Gridder Expanded");
    },
    onChanged: function(object) {
      //console.log("Gridder Changed");
    },
    onClosed: function() {
      //console.log("Gridder Closed");
    }
  });

  $(".gridder-list").each(function() {

    var ytv = $(this).attr("data-griddercontent");
    var vdlink = $(this).find(".youtube a").attr("href")
    console.log(ytv)

    $(ytv).find("iframe").attr("src", vdlink)

  })



});


// ------- video overlay filter end
