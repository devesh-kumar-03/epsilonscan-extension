How to install NPM to run Front end :

* install (npm install) by command prompt.
it will install all the module and gulp task.


After install the NPM :

Run (npm start) by command prompt to generate the CSS from SCSS.






