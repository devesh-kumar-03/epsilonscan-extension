#! /bin/sh

rm -rf style-guide/assets;
# rm -rf style-guide/css;
rm -rf style-guide/js;
rm -rf style-guide/views;
rm -f style-guide/*.*

./node_modules/.bin/kss --config kss-config.json
