'use strict';

/*************************************************************
 * Variables
 ************************************************************/
// Globals
var paths = global.paths;

global.config.sass = {
    enabled: true,
    src: paths.sass + '*.scss',
    watchSrc: paths.sass + '**/*.scss',
    dest: paths.buildCss,
    flattenDestOutput: true,
    cleanCss: false,
    lint: {
        enabled: false,
        failOnError: true,
        configFile: paths.baseDir + '.sass-lint.yml'
    },
    sassOptions: {
        outputStyle: 'compressed',
        eyeglass: {
            enableImportOnce: false
        }
    },
    sourceComments: false,
    sourceMapEmbed: false,
    outputStyle: 'compressed',
    autoPrefixerBrowsers: [
        'last 4 versions',
        'IE >= 9',
        '> 1.49%'
    ],
    includePaths: (['./node_modules']),
    docs: {
        enabled: false,
        dest: paths.buildDir + '/sassdoc',
        verbose: false,
        sort: [
            'file',
            'group',
            'line'
        ],
        exclude: []
    },
    sizeReport: {
        enabled: false,
        options: {
            '*': {
                'maxSize': 70000 // Alert if > Max Size in Bytes after gzip
            }
        }
    }
};


//export purple theme css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/theme_purple.scss']
    },
    buildLocations: {
        css: './css/'
    }
}

//export white theme css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/theme_white.scss']
    },
    buildLocations: {
        css: './css/'
    }
}

//export white theme css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/microsite_custom.scss']
    },
    buildLocations: {
        css: './css/'
    }
}


//export white theme css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/theme_student.scss']
    },
    buildLocations: {
        css: './css/'
    }
}



//export library css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/library_custom.min.scss']
    },
    buildLocations: {
        css: './css/'
    }
}

//export staff css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/staff.scss']
    },
    buildLocations: {
        css: './css/'
    }
}

//export staff css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/policies.scss']
    },
    buildLocations: {
        css: './css/'
    }
}


//export white theme css
module.exports = {
    app: { baseName: 'public' },
    sass: {
        src: ['./scss/theme_staff.scss']
    },
    buildLocations: {
        css: './css/'
    }
}

//export print css
// module.exports = {
//     app: { baseName: 'public' },
//     sass: {
//         src: ['./scss/print.scss']
//     },
//     buildLocations: {
//         css: './css/'
//     }
// }