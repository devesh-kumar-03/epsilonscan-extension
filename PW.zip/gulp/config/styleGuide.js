'use strict';

/*************************************************************
 * Variables
 ************************************************************/
// Globals
var paths = global.paths;

var styleGuideTitle = 'ACU style guide';


global.config.styleGuide = {
  enabled: false,
  generator: 'kss',
  sc5: {
    src: paths.buildStyleGuideSrc + '/*.css',
    dest: paths.styleGuide,
    repo: 'https://github.com/SC5/sc5-styleguide',

    sc5Settings: {
      title: styleGuideTitle,
      extraHead: [
        '<script src="../assets/vendor/js/jquery-3.2.1.min.js"></script>',
        '<script src="../assets/vendor/js/svg4everybody.min.js"></script>',
        '<script src="../assets/vendor/js/bootstrap.min.js"></script>',
        '<script src="../assets/vendor/js/popper.min.js"></script>',
        '<script src="../assets/vendor/js/scrollPosStyler.min.js"></script>',
        '<script src="../assets/vendor/js/modernizr-custom.min.js"></script>',
        '<script src="../js/styleguide.js"></script>',
      ],
      server: false,
      rootPath: paths.baseDir,
      appRoot: './',
      overviewPath: paths.sass + 'overview.md',
      disableHtml5Mode: true,
      sideNav: true,
      disableEncapsulation: true
    },
    sc5Node: [
      'rm -f ' + paths.baseDir + 'style-guide/*.*',
      'rm -rf ' + paths.baseDir + 'style-guide/assets ' + paths.baseDir + 'style-guide/js ' + paths.baseDir + 'style-guide/views ' + paths.baseDir + 'style-guide/css',
      paths.baseDir + 'node_modules/.bin/sc5 --config ' + paths.baseDir + 'sc5-config.json'
    ],
  },
  kss: {
    src: paths.buildStyleGuideSrc + '/*.css',
    dest: paths.styleGuide,
    home: 'https://holidaypirates.github.io/nucleus/',
    repo: 'https://github.com/kss-node/kss-node',
    kssNode: [
      'rm -f ' + paths.baseDir + 'style-guide/*.*',
      'rm -rf ' + paths.baseDir + 'style-guide/assets ' + paths.baseDir + 'style-guide/js ' + paths.baseDir + 'style-guide/views ' + paths.baseDir + 'style-guide/css',
      paths.baseDir + 'node_modules/.bin/kss --config ' + paths.baseDir + 'kss-config.json'
      // paths.baseDir + 'kss.sh'
    ],
    template: {
      default: './node_modules/kss/lib/',
      druff: './node_modules/gulp-kss-druff/./node_modules/kss/lib/template',
      michelangelo: 'node_modules/michelangelo/kss_styleguide/custom-template/'
    },
    kssSettings: {
      // builder: styleGuide.template.michelangelo,
      builder: paths.baseDir + 'node_modules/michelangelo/kss_styleguide/custom-template',
      multiline: true,
      homepage: paths.baseDir + "assets/scss/overview.md",
      typos: false,
      custom: [],
      helpers: '',
      css: [
        '../fonts/MyFontsWebfontsKit/MyFontsWebfontsKit.css',
        '../fonts/tmp-fonts.css',
        '../css/bootstrap-4.0.0-beta/scss/bootstrap-reboot.css',
        '../css/bootstrap-4.0.0-beta/scss/bootstrap-grid.css',
        '../css/bootstrap-4.0.0-beta/scss/bootstrap.css',
        '../css/acu-style.css'
      ],
      js: [
        '../vendor/js/jquery-3.2.1.min.js',
        '../vendor/js/bootstrap.min.js',
        '../vendor/js/popper.min.js',
        '../vendor/js/scrollPosStyler.min.js',
        '../vendor/js/modernizr-custom.min.js'
      ]
    }
  },
  nucleus: {
    src: paths.sass + '**/*.scss',
    dest: paths.styleGuide,
    home: 'https://holidaypirates.github.io/nucleus/',
    repo: '',
    nucleusNode: [
      'rm -f ' + paths.baseDir + 'style-guide/*.*',
      'rm -rf ' + paths.baseDir + 'style-guide/assets ' + paths.baseDir + 'style-guide/js ' + paths.baseDir + 'style-guide/views ' + paths.baseDir + 'style-guide/css',
      paths.baseDir + 'node_modules/.bin/nucleus --config ' + paths.baseDir + 'nucleus-config.json'
    ]
  }
  // patternLab: {
  //   enabled: true,
  //   path: paths.baseDir + 'pattern-lab/',
  //   configFile: paths.baseDir + 'pattern-lab/config/config.yml',
  //   watchedExtensions: (['twig', 'json', 'yaml', 'yml', 'md', 'jpg', 'jpeg', 'png']),
  //   scssToJson: [
  //     {
  //       src: paths.relative + 'components/_patterns/00-base/03-colors/_00-colors__vars.scss',
  //       dest: paths.relative + 'components/_patterns/00-base/03-colors/colors.json',
  //       lineStartsWith: '$',
  //       allowVarValues: false,
  //       excludeVars : [
  //         '$palettes'
  //       ]
  //     }
  //   ]
  // }
};
