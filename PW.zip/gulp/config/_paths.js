'use strict';
var path = require("path");
/*************************************************************
 * Variables
 ************************************************************/
// Local
var baseDir = process.cwd() + '/'; // Theme folder (where gulp is running)
baseDir = baseDir.replace(/[\\\\]/g, '/');

var assetsDir = baseDir;
var buildDir = baseDir; // Output folder in theme


// Global
global.paths = {
    relative: './',
    baseDir: baseDir,
    js: [
        // baseDir + '/components/_patterns/**/*.js',
        //assetsDir + '/js/bootstrap/*.js',
        //assetsDir + '/js/vendor/*.js',
        //assetsDir + '/js/*.js',
        //assetsDir + '/js/utilityFunctions.js',
        //assetsDir + '/js/headerUI.js',
        // buildDir + '/js/**/*.js',
    ],
    sass: assetsDir + 'scss/',
    img: assetsDir + 'img/',
    buildDir: buildDir,
    buildJs: buildDir + 'js/',
    buildCss: buildDir + 'css/',
    buildStyleGuideSrc: buildDir + 'styleGuideSrc/',
    buildImg: buildDir + 'img/',
    buildSvg: buildDir + 'svg/',
    styleGuide: 'style-guide/'
};