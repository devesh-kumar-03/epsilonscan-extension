'use strict';

require('./_paths.js');
/*************************************************************
 * Variables
 ************************************************************/
// Local
var localUrl = ''; // EG 'localhost', 'mysite.dev', leave blank for
// Globals
var paths = global.paths;


global.config.browserSync = {
    ui: true,
    enabled: true,
    baseDir: './',
    domain: localUrl,
    defaults: {
        startPath: paths.styleGuide,
        open: true,
        browser: "chrome",
        reloadDelay: 50,
        reloadDebounce: 750,
    },
};


global.config.wpt = {
    // WebPageTest API key https://www.webpagetest.org/getkey.php
    // key:
};