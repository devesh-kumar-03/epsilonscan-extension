'use strict';

var path = require("./_paths");

/*************************************************************
 * Variables
 ************************************************************/
// Globals
var paths = global.paths;

global.config.js = {
  src: paths.js,
  dest: paths.buildJs,
  sourceMapEmbed: true,
  babel: {
    presets: ['es2015-without-strict'],
  },
  hint: {
    enabled: false,
    src: paths.js,
  },
  lint: {
    enabled: false,
    src: paths.js,
    options: {
      path: paths.baseDir + '.eslint.js'
    }
  },
  sizeReport: {
    enabled: false,
    options: {
      '*': {
        'maxSize': 200000 // Alert if > Max Size in Bytes after gzip
      }
    }
  },
  cleanJs: false
};
