/* globals require, process, global, console */

var gulp = global.gulp;

var tasks = global.tasks;
var browserSync = global.browserSync;
var paths = global.paths;

if (!global.config.styleGuide.enabled) {
  return;
}

switch(global.config.styleGuide.generator) {
  // -------------------------------------------------------------
  // START: SC5 setup

  case 'sc5':
    var gulp = require('gulp');
    var styleguide = require('sc5-styleguide');
    var sass = require('gulp-sass');

    var styleGuide = global.config.styleGuide.sc5; 

    gulp.task('sc5:build', function() {
      return gulp.src(styleGuide.src)
        .pipe(styleguide.generate(styleGuide.sc5Settings))
        .pipe(gulp.dest(styleGuide.dest));
    });

    gulp.task('sc5:applystyles', function() {
      return gulp.src(styleGuide.src)
        // .pipe(sass({
        //   errLogToConsole: true
        // }))
        .pipe(styleguide.applyStyles())
        .pipe(gulp.dest(styleGuide.dest))
        .pipe(browserSync.stream({match: '**/*.html'}));
    });

    gulp.task('sc5:watch', ['sc5'], function() {
      // Start watching changes and update styleguide whenever changes are detected
      // Styleguide automatically detects existing server instance
      gulp.watch([styleGuide.src], ['sc5']);
    });

    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Builders
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    gulp.task('sc5', 'Build SC5 living style guide', ['sc5:build', 'sc5:applystyles']);
    tasks.compile.push('sc5');

    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Watchers
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    tasks.watch.push('sc5:watch');
    
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // BrowserSync
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    // Generate Tasks creates the styleguide files
    gulp.task('sc5:generateBrowserSync', function() {
      var browserSync  = require('browser-sync').get('bs');

      return gulp.src(styleGuide.src)
        .pipe(styleguide.generate(styleGuide.sc5Settings))
        .pipe(gulp.dest(styleGuide.dest))
        .pipe(browserSync.stream({match:['**/*.json','**/*.html']}));
    });

    // Apply Styles: Parses CSS outpiut to Generate :hover
    // & other pseudo elements as classes for display in the styleguide
    gulp.task('styleGuide:BrowserSync', ['sc5:generateBrowserSync'], function() {
      var browserSync  = require('browser-sync').get('bs');

      return gulp.src(styleGuide.src)
        .pipe(styleguide.applyStyles())
        .pipe(gulp.dest(styleGuide.dest))
        .pipe(browserSync.stream({match: '**/*.css'}));
    });

    break;


  //  END:  SC5 setup
  // -------------------------------------------------------------


  // -------------------------------------------------------------
  // START: KSS setup

  case 'kss':
    // var gulpkss = require('gulp-kss-druff');
    var shell = require('gulp-shell');
    var styleGuide = global.config.styleGuide.kss; 

    // reworking of kss build process for Gulp came directly from
    // https://www.triplet.fi/blog/avoiding-unnecessary-gulp-plugins/
    gulp.task('kss:build', shell.task(styleGuide.kssNode));

    gulp.task('kss:watch', ['kss'], function() {
      // Start watching changes and update styleguide whenever changes are detected
      // Styleguide automatically detects existing server instance
      gulp.watch([styleGuide.src], ['kss']);
    });
    
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Builders
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    gulp.task('kss', 'Build KSS living style guide', ['kss:build']);
    tasks.compile.push('kss');

    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Watchers
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    tasks.watch.push('kss:watch');
    
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // BrowserSync
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    // Generate Tasks creates the styleguide files
    gulp.task('kss:generateBrowserSync', function() {
      var browserSync  = require('browser-sync').get('bs');

      return gulp.src(styleGuide.src)
        .pipe(styleguide.generate(styleGuide.sc5Settings))
        .pipe(gulp.dest(styleGuide.dest))
        .pipe(browserSync.stream({match:['**/*.json','**/*.html']}));
    });

    // Apply Styles: Parses CSS outpiut to Generate :hover
    // & other pseudo elements as classes for display in the styleguide
    gulp.task('styleGuide:BrowserSync', ['kss:generateBrowserSync'], function() {
      var browserSync  = require('browser-sync').get('bs');

      return gulp.src(styleGuide.src)
        .pipe(styleguide.applyStyles())
        .pipe(gulp.dest(styleGuide.dest))
        .pipe(browserSync.stream({match: '**/*.css'}));
    });
    break;

  //  END:  KSS setup
  // -------------------------------------------------------------


  // -------------------------------------------------------------
  // START: Nucleus setup

  case 'nucleus':
    break;
  
  //  END:  Nucleus setup
  // -------------------------------------------------------------
}