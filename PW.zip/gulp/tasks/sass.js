'use strict';

/*************************************************************
 * Variables
 ************************************************************/
// Modules
var del = require('del');
var sassdoc = require('sassdoc');
// var sassLint = require('gulp-sass-lint');
// var rename = require('gulp-rename');
// var normalizeScss = require('node-normalize-scss');
var compass = require('compass-importer');
var paths = global.paths;

// Globals
var gulp = global.gulp;
var scss = global.config.sass;


var tasks = global.tasks;
var browserSync = global.browserSync;

/*************************************************************
 * Operations
 ************************************************************/
gulp.task('sass:compile', 'Compile Scss to CSS using Libsass with Autoprefixer and SourceMaps', function () {
  return gulp.src(scss.src)
    .pipe(gulp.$.sassGlob())
    .pipe(gulp.$.plumber({
      errorHandler: function (error) {
        gulp.$.notify.onError({
          title: 'CSS <%= error.name %> - Line <%= error.line %>',
          message: '<%= error.message %>'
        })(error);
        this.emit('end');
      }
    }))
    .pipe(gulp.$.sourcemaps.init({
      debug: config.debug
    }))
    .pipe(gulp.$.sass({
      importer: compass,
      outputStyle: scss.sassOptions.outputStyle,
      sourceComments: scss.sourceComments,
      // includePaths: normalizeScss.with(scss.includePaths)
    }).on('error', gulp.$.sass.logError))
    // use auto prefixer to get most appropriate vendor prefixing
    // .pipe(gulp.$.autoprefixer(scss.autoPrefixerBrowsers))
    // write raw (unminified, with commments) css to styleguide directory
    .pipe(gulp.dest(paths.buildStyleGuideSrc))
    .pipe(gulp.$.sourcemaps.init())
    // .pipe(gulp.$.cleanCss())
    .pipe(gulp.$.sourcemaps.write((scss.sourceMapEmbed) ? null : './'))
    // .pipe(gulp.$.if(scss.flattenDestOutput, gulp.$.flatten()))
    // write fully minified css to build directory.
    // .pipe(rename({ extname: '.min.css' }))
    .pipe(gulp.dest(scss.dest))
    .pipe(gulp.$.if(scss.sizeReport.enabled,
      gulp.$.sizereport(scss.sizeReport.options)
    ))
    .pipe(browserSync.stream({match: '**/*.css'}));
});

if (scss.cleanCss) {
  gulp.task('sass:clean', 'Delete compiled CSS files', function (done) {
    del([
      scss.dest + '*.{css,css.map}'
    ]).then(function () {
      done();
    });
  });
}

gulp.task('sass:lint', 'Lint Scss files', function () {
  var src = scss.watchSrc;
  if (scss.lint.extraSrc) {
    src = src.concat(scss.lint.extraSrc);
  }
  return gulp.src(src)
    .pipe(gulp.$.cached('validate:css'))
    .pipe(gulp.$.sassLint())
    .pipe(gulp.$.sassLint.format())
    .pipe(gulp.$.if(scss.lint.failOnError, gulp.$.sassLint.failOnError()));
});

gulp.task('sass:docs', 'Build CSS docs using SassDoc', function () {
  return gulp.src(scss.src)
    .pipe(sassdoc({
      dest: scss.docs.dest,
      verbose: scss.docs.verbose,
      basePath: scss.docs.basePath,
      exclude: scss.docs.exclude,
      theme: scss.docs.theme,
      sort: scss.docs.sort
    }));
});

gulp.task('sass:docs:clean', 'Delete compiled CSS docs', function (done) {
  del([
    scss.docs.dest
  ]).then(function () {
    done();
  });
});

/*************************************************************
 * Builders
 ************************************************************/
var sassTasks = ['sass:compile'];
if (scss.lint.enabled) {
  sassTasks.push('sass:lint');
}
// if (scss.docs.enabled) {
//   sassTasks.push('sass:docs');
//   tasks.clean.push('sass:docs:clean');
// }

gulp.task('sass', 'Execute all configured Sass actions (compile, optional lint/sourcemaps based on config)', sassTasks);
tasks.compile.push('sass');
if (scss.cleanCss) {
  tasks.clean.push('sass:clean');
}
tasks.validate.push('sass:lint');

/*************************************************************
 * Watchers
 ************************************************************/
gulp.task('sass:watch', function () {
  return gulp.watch(scss.watchSrc, sassTasks);
});
tasks.watch.push('sass:watch');
