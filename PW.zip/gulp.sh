#! /bin/sh


./node_modules/.bin/gulp
