/* global $, console */
/* jslint browser: true */
/* jshint browser: true */
/* eslint browser: true */
/* jslint devel: true */
/* jslint strict: 0*/

var currentYear = new Date().getFullYear(),
    ryi_year = $('.ryi-year'),
    ryi_form = $(".ryi-form");
// the two ryi_ variables above were created for performance because their jQuery selectors were used nearly 100 times in the code below. It will be much faster to assign the variables and re-use them than to re-select.

$(document).ready(function() {

    $(".disabled-ryi").attr("disabled", true);

    // console.log("page load");

    $('.ryi-year option').remove();
    ryi_year.prop('selectedIndex', 0);
    ryi_form.parent("form").parent("div").addClass("form-container");
    $(".ryi-area-first").prev().find(".mandatory").addClass("hide");
    $('.ryi-year option').remove();
    ryi_year
        .append('<option value="select" selected ->select</option>')
        .prop('selectedIndex', 0);

    var yearvalue = ryi_year.find('option:selected').val(),
        selectedValue = $('.ryi-student').find('option:selected').val(),
        ryiLength = $('.ryi-student option:selected').index();


    if ($('.ryi-campus-first').hasClass("disabled-ryi")) {

        $('.ryi-campus-first').prev().html('Campus preference 1');


        // I am a selection function
        var selectedValuecamp = $('.ryi-campus-first').find('option:selected').val(),
            i;
        // console.log(selectedValuecamp);

        $(document).on('change', '.ryi-student', function() {

            console.log("single campus form");

            $('.ryi-campus-first option').remove();
            $('.ryi-campus-first').append('<option value="' + selectedValuecamp + '">' + selectedValuecamp + '</option>');

            var selectedValue = $('.ryi-student').find('option:selected').val(),
                ryiLength = $('.ryi-student option:selected').index();

            ryi_year.prop('selectedIndex', 0);
            // Chained methods below for performance
            $('.ryi-area-first')
                .prop('selectedIndex', 0)
                .prev().find(".mandatory").addClass("hide");
            $('.ryi-area-ryi-area-second').prop('selectedIndex', 0);


            var res = $('.ryi-student').is(function(i, el) {
                return el.selectedIndex === 0
            });

            if (res) {
                //alert("hi");
                $('.ryi-information').hide();
                // code added for year hide
                $(".ryi-form").parent("form").parent("div").addClass("form-container");
                // Chained methods below for performance
                ryi_year
                //.addClass("hide")
                    .prop('selectedIndex', 0);



            } else if (selectedValue === 'School student') {

                $('.ryi-information').hide();
                $('.school_student').show();
                // code added for year show
                $(".ryi-form").parent("form").parent("div").removeClass("form-container");
                // Chained methods below for performance
                ryi_year.prev()
                    .html('Year you will graduate school. <span class="mandatory">(required)</span>')

                // Chained methods below for performance
                $('.ryi-year option').remove();
                ryi_year.attr('disabled', false); //can't chain attributes.
                ryi_year
                    .prop('selectedIndex', 0)
                    //.removeClass("hide")
                    .append('<option value=""></option>');
                for (i = currentYear; i < (currentYear + 6); i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }
                //console.log("School student");


            } else if (selectedValue === 'Non-school leaver') {
                studyValid();
                yearunValid()

                $('.ryi-information').hide();
                $('.school_non').show();
                // code added for year hide
                //$(".ryi-form").parent("form").parent("div").addClass("form-container");
                // Chained methods below for performance
                ryi_year


                ryi_form.parent("form").parent("div").addClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year
                    .append('<option value="" ></option>')
                    .prop('selectedIndex', 0);

                //console.log("Non-school leaver")


            } else if (selectedValue === 'School leaver') {
                studyValid();
                yearValid()

                $('.ryi-information').hide();
                $('.school_leaver').show();

                // Chain methods
                ryi_year
                // .removeClass("hide")
                    .prop('selectedIndex', 0)
                    .prop('disabled', false)
                    .prev()
                    // 
                    .html('Year you graduated school. <span class="mandatory">(required)</span>');
                ryi_form.parent("form").parent("div").removeClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>');
                // CHANGES: Removed hard-coded starting year.
                for (i = currentYear - 3; i < currentYear; i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }


            } else if (selectedValue === 'Postgraduate') {
                studyValid();
                yearunValid()

                $('.ryi-information').hide();
                $('.school_post').show();

                // Chained methods below for performance
                ryi_year
                    .prop('selectedIndex', 0)
                    //.addClass("hide").prev()

                ryi_form.parent("form").parent("div").addClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>').prop('selectedIndex', 0);

            } else if (selectedValue === 'Parent') {
                studyunValid();
                yearValid()
                $('.ryi-information').hide();
                $('.school_parent').show();
                // Chained methods below for performance
                ryi_year
                    .prop('disabled', false)
                    .prop('selectedIndex', 0)
                    //.removeClass("hide")
                    .prev()
                    .html('Year your teenager will graduate school. <span class="mandatory">(required)</span>')

                ryi_form.parent("form").parent("div").removeClass("form-container");
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>');
                for (i = currentYear; i < (currentYear + 6); i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }


            } else if (selectedValue === 'Research') {
                studyValid();
                yearunValid()

                $('.ryi-information').hide();
                $('.school_research').show();
                // Chained methods below for performance
                ryi_year
                //.addClass("hide")

                //TODO: Check if below line should be uncommented
                //$('.ryi-year').prop('selectedIndex', 0);
                ryi_form.parent("form").parent("div").addClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year.prop('selectedIndex', 0).append('<option value="" ></option>');

            }

        });
    } else {
        // I am a selection function
        // multiple campus form 
        $(document).on('change', '.ryi-student', function() {
            console.log("multiple campus form ");

            var selectedValue = $('.ryi-student').find('option:selected').val(),
                ryiLength = $('.ryi-student option:selected').index();

            ryi_year.prop('selectedIndex', 0);
            $('.ryi-campus-first').prop('selectedIndex', 0);
            $('.ryi-campus-second').prop('selectedIndex', 0);
            $('.ryi-area-first').prop('selectedIndex', 0);
            $('.ryi-area-ryi-area-second').prop('selectedIndex', 0);
            $(".ryi-area-first").prev().find(".mandatory").addClass("hide");


            var res = $('.ryi-student').is(function(i, el) {
                return el.selectedIndex === 0
            });

            if (res) {
                //alert("hi");
                $('.ryi-information').hide();
                // code added for year hide
                $(".ryi-form").parent("form").parent("div").addClass("form-container");
                //$('.ryi-year').prev().addClass("hide");
                //ryi_year.prop('selectedIndex', 0).addClass("hide");
                studyunValid();

            } else if (selectedValue === 'School student') {
                studyunValid();
                yearValid();

                $('.ryi-information').hide();
                $('.school_student').show();

                //ryi_year.prev()
                ryi_form.parent("form").parent("div").removeClass("form-container");

                // Chained methods below for performance
                ryi_year.attr('disabled', false);
                ryi_year
                    .prop('selectedIndex', 0)
                    .prev().html('Year you will graduate school. <span class="mandatory">(required)</span>');
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>');
                for (i = currentYear; i < (currentYear + 6); i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }

                // console.log("School student");

            } else if (selectedValue === 'Non-school leaver') {
                studyValid();
                yearunValid();

                $('.ryi-information').hide();
                $('.school_non').show();

                // Chained methods below for performance
                ryi_year
                    .prev()
                    .prop('selectedIndex', 0)
                    //
                ryi_form.parent("form").parent("div").addClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                // Chained methods below for performance
                ryi_year
                    .append('<option value="" ></option>')
                    .prop('selectedIndex', 0);

                // console.log("Non-school leaver");


            } else if (selectedValue === 'School leaver') {
                studyValid();
                yearValid();

                $('.ryi-information').hide();
                $('.school_leaver').show();
                ryi_year
                    .prev()
                    .html('Year you graduated school. <span class="mandatory">(required)</span>')
                    //
                ryi_form.parent("form").parent("div").removeClass("form-container");
                //$('.ryi-year').removeClass("hide");
                ryi_year.prop('selectedIndex', 0);
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                // Chained methods below for performance
                ryi_year
                    .prop('disabled', false)
                    .append('<option value=""></option>');
                for (i = currentYear - 3; i < currentYear; i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }

                // console.log("School leaver");


            } else if (selectedValue === 'Postgraduate') {
                studyValid();
                yearunValid();

                $('.ryi-information').hide();
                $('.school_post').show();
                // Chained methods below for performance
                ryi_year
                    .prop('selectedIndex', 0)
                    //
                ryi_form.parent("form").parent("div").addClass("form-container");
                //$('.ryi-year').addClass("hide");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>').prop('selectedIndex', 0);
                // console.log("Postgraduate");

            } else if (selectedValue === 'Parent') {

                yearValid();

                $('.ryi-information').hide();
                $('.school_parent').show();
                ryi_year
                    .prev()
                    .html('Year your teenager will graduate school. <span class="mandatory">(required)</span>')

                ryi_form.parent("form").parent("div").removeClass("form-container");
                // Chained methods below for performance
                ryi_year
                    .prop('selectedIndex', 0)
                    .prop('disabled', false);
                $('.ryi-year option').remove();
                ryi_year.append('<option value=""></option>');
                for (i = currentYear; i < (currentYear + 6); i++) {
                    ryi_year.append('<option value="' + i + '">' + i + '</option>');
                }

                // console.log("Parent");

            } else if (selectedValue === 'Research') {
                studyValid();
                yearunValid();

                $('.ryi-information').hide();
                $('.school_research').show();
                ryi_year
                    .prop('selectedIndex', 0)
                    .prev()

                ryi_form.parent("form").parent("div").addClass("form-container");
                $(".ryi-area-first").prev().find(".mandatory").show();
                $('.ryi-year option').remove();
                ryi_year.append('<option value="" ></option>').prop('selectedIndex', 0);

                // console.log("Research");

            }

        });

    }


    function studyValid() {
        var TempRef = $('.ryi-area-first');
        TempRef.prev().html('Study area preference 1 <span class="mandatory">(required)</span>');
        TempRef.attr("aria-required", "true");
        TempRef.attr("required", "required");
        TempRef.attr("data-val", "true");
        TempRef.next(".field-validation-error").show();
        TempRef.addClass("input-validation-error")
    }

    function studyunValid() {
        var TempRef = $('.ryi-area-first');
        TempRef.prev().html('Study area preference 1 <span class="non-mandatory">(optional)</span>');
        TempRef.attr("aria-required", "false");
        TempRef.removeAttr("required");
        TempRef.attr("data-val", "false");
        TempRef.next(".field-validation-error").hide();
        TempRef.removeClass("input-validation-error")
    }

    function yearValid() {
        ryi_year.attr("aria-required", "true");
        ryi_year.attr("required", "required");
        ryi_year.attr("data-val", "true");
        $(".ryi-year").next(".field-validation-error").show();
    }

    function yearunValid() {
        ryi_year.attr("aria-required", "false");
        ryi_year.attr("required");
        ryi_year.attr("data-val", "false");
        $(".ryi-year").next(".field-validation-error").hide();
    }

    // year selection function
    $(document).on('click', '.ryi-year', function() {


        var selectedValue = $('.ryi-student').find('option:selected').val(),
            yearvalue = $(".ryi-year").find('option:selected').val();

        // console.log(selectedValue);
        // console.log(yearvalue);

        //$('.ryi-area-first').prop('selectedIndex', 0);

        if (yearvalue === currentYear.toString() && selectedValue === 'School student') {
            $(".ryi-area-first").prev().find(".mandatory").show();
            studyValid();
            yearValid();
            ryi_year.show();

        } else if (selectedValue === 'School leaver') {
            $(".ryi-area-first").prev().find(".mandatory").show();
            studyValid();
            yearValid();
            ryi_year.show();

        } else if (selectedValue === 'Postgraduate') {
            $(".ryi-area-first").prev().find(".mandatory").show();
            studyValid();
            yearunValid();
            ryi_year.addClass("hide");

        } else if (yearvalue === currentYear.toString() && selectedValue === 'Parent') {
            $(".ryi-area-first").prev().find(".mandatory").show();
            studyValid();
            yearValid();
            ryi_year.show();

        } else if (selectedValue === 'Research') {
            $(".ryi-area-first").prev().find(".mandatory").show();
            studyValid();
            yearunValid();

            ryi_year.addClass("hide");

        } else {
            $(".ryi-area-first").prev().find(".mandatory").addClass("hide");
            studyunValid();
            yearunValid();


        }

    });

});


// Minify this file before deploying to prodcution.
// Define any global variables / field id's here
/* CHANGES added new variable to manage the one-campus scenario.
// Set this to true when applying this javascript to a single campus form.
// The form will also need some editing to set the campus value to the desired one
*/
var singleCampus = false; //AL - 12/04/2019 - set to "true" for single campus.
var personalEmailClickDimensionsId = "f_52b6933e750ee1118e7c1cc1de6d5b2d";
var mobilePhoneClickDimensionsId = "f_d4ebc08e3f25e1118efc1cc1de6d5b2d";
var studentTypeClickDimensionsId = $(".ryi-student").attr("ID"); //"f_153a5b6f1c15e81181f070106faa3061";
var studentGradYearClickDimensionsId = $(".ryi-year").attr("ID"); //"f_51c35def1e15e8118123e0071b673bb1";//f_ff0c4993d328e811811de0071b668851";
//var studentGradYearClickDimensionsIdAlt = "f_ff6acaa6c0154567ac65d8b66bcc8a11";
var campusPreferenceClickDimensionsId = $(".ryi-campus-first").attr("ID"); //"f_8c0370ffab2ee6118139c4346bac1e5c";//f_68b33464b52041d4ad2a65c0a7887112";
var campusPreference2ClickDimensionsId = $(".ryi-campus-second").attr("ID"); //"f_0efaa089ac2ee6118139c4346bac1e5c";//f_4e530c1a2dd34e77a4eb16cc28b73264";
var studyAreaPreferenceClickDimensionsId = $(".ryi-area-first").attr("ID"); //"f_6209b9930f1de81181f370106faa3061";//f_687bfb4aaf034ca58c5533eb5ef90691";
var studyAreaPreference2ClickDimensionsId = $(".ryi-area-second").attr("ID"); //"f_477d0db30f1de81181f370106faa3061";//f_2947927489ce43ee9e27493263bdb3f0";


//Implementation of replaceAt function, it's not supported by some older versions of firefox/IE.
String.prototype.replaceAt = function(index, replacement) {
    return this.substr(0, index) + replacement + this.substr(index + replacement.length);
};

//Implementation of the forEach array iterator, not included/supported in IE/Edge
if (!Array.prototype.forEach) {
    Array.prototype.forEach = function(fn, scope) {
        for (var i = 0, len = this.length; i < len; ++i) {
            fn.call(scope, this[i], i, this);
        }
    }
}

//Implementation of startsWith, not included/supported in IE/Edge
if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position) {
        position = position || 0;
        return this.indexOf(searchString, position) === position;
    };
}

// Function used for setup process to ensure everything is ready before starting the setup.
var waitCount = 0;

function waitForWidgetLoad() {

    //Try and get the mobile phone control, if it retrieves the control, our form has loaded correctly
    if (document.getElementById(mobilePhoneClickDimensionsId) == undefined && waitCount < 5) {
        //console.log("still waiting for form...");
        waitCount++;
        setTimeout(waitForWidgetLoad, 1000);
        return
    }
    //console.log("Got form element or timed out waitcount = " + waitCount);
}
waitForWidgetLoad();

$(window).on('load', (function() {
    try {
        //Check for any ID's that changed from UAT to PROD
        if ($("#" + studentGradYearClickDimensionsId)[0] == undefined) {
            studentGradYearClickDimensionsId = studentGradYearClickDimensionsIdAlt;
        }

        if ($("#" + studyAreaPreferenceClickDimensionsId)[0] == undefined) {
            studyAreaPreferenceClickDimensionsId = "f_6209b9930f1de81181f370106faa3061";
            if ($("#" + studyAreaPreferenceClickDimensionsId)[0] == undefined) {
                studyAreaPreferenceClickDimensionsId = "f_687bfb4aaf034ca58c5533eb5ef90691";
            }
        }

        if ($("#" + studyAreaPreference2ClickDimensionsId)[0] == undefined) {
            studyAreaPreference2ClickDimensionsId = "f_477d0db30f1de81181f370106faa3061";
            if ($("#" + studyAreaPreference2ClickDimensionsId)[0] == undefined) {
                studyAreaPreference2ClickDimensionsId = "f_2947927489ce43ee9e27493263bdb3f0";
            }
        }

        if ($("#" + studentTypeClickDimensionsId)[0] == undefined) {
            studentTypeClickDimensionsId = "f_0df2edc6590e48c8919a2ec3390ff5ac";
            if ($("#" + studentTypeClickDimensionsId)[0] == undefined) {
                studentTypeClickDimensionsId = "f_153a5b6f1c15e81181f070106faa3061";
            }
        }
        //Call the getLabel function to ensure they have id's
        //These functions are benign and won't cause issues if the elements dont exist
        //getSubmissionConditionsLabel();
        getLabelFromInputID(studyAreaPreferenceClickDimensionsId);
        getLabelFromInputID(studentGradYearClickDimensionsId);

        // Check that the student type control exists before trying to load this stuff. It can be removed on some versions of the form.
        // This section of code sets up the dropdowns, so that code is run whenever the user changes their value.
        // Student Type
        if ($("#" + studentTypeClickDimensionsId)[0] != undefined) {
            // CHANGES: Hide the campus 2 and Study area 2 sections of the form.
            if (singleCampus) {
                $("div.responsiveCell:has(select#" + studyAreaPreference2ClickDimensionsId + "),div.responsiveCell:has(select#" + campusPreference2ClickDimensionsId + ")").addClass("hide");

                //08-11032019 - ADDED: Code to modify Campus Preference 1 if singleCampus activated.
                var label2Text = "Campus preference" + (singleCampus ? "" : " 1");
                var campusPreferenceLabel = getLabelFromInputID(campusPreferenceClickDimensionsId);
                campusPreferenceLabel.innerHTML = label2Text + "<span class='requiredStar'>*</span>";
            }
            $(document).on("change", "#" + studentTypeClickDimensionsId, function() {

                // console.log("student ID");

                //Check the emelements that are impacted by the student type exist on the form before trying to load them
                if ($("#" + campusPreferenceClickDimensionsId)[0] !== undefined) {
                    setStudyAreaByCampus(campusPreferenceClickDimensionsId, studyAreaPreferenceClickDimensionsId);
                    if (!singleCampus) {
                        //13032019 - REMOVED: Allowing Study Area preferences 1 or 2 to NOT be determined by the Campus("singleCampus" variable)
                        setStudyAreaByCampus(campusPreference2ClickDimensionsId, studyAreaPreference2ClickDimensionsId);
                    }
                }
                if ($("#" + studyAreaPreferenceClickDimensionsId)[0] !== undefined) {
                    setStudyAreaRequiredLevel();
                }

                if ($("#" + studentGradYearClickDimensionsId)[0] !== undefined) {
                    setGraduationRequiredLevelAndText();
                }
                if ($("#selectedStudentTypeDiv")[0] !== undefined) {
                    showStudentTypeTooltipText();
                }
                // Call the new function to remove the campuses for 2 audience scenarios.
                if (($("#" + studentTypeClickDimensionsId)[0] !== undefined) && (!singleCampus)) {
                    var studentTypeDropDown;
                    studentTypeDropDown = $("#" + studentTypeClickDimensionsId)[0];
                    hideCampus(studentTypeDropDown[studentTypeDropDown.selectedIndex].text);
                }
            });

            //Logic requries that a student type be specified to manage the list of study areas
            /* CHANGES: This form has a static, hidden campus field, so don't need events to fire when this field is changed (because it doesn't change!).*/

            // Campus 1
            $(document).on("change", "#" + campusPreferenceClickDimensionsId, function() {
                setStudyAreaByCampus(campusPreferenceClickDimensionsId, studyAreaPreferenceClickDimensionsId);
            });
            //Logic requries that a student type be specified to manage the list of study areas
            // Campus 2
            $(document).on("change", "#" + campusPreference2ClickDimensionsId, function() {
                setStudyAreaByCampus(campusPreference2ClickDimensionsId, studyAreaPreference2ClickDimensionsId);
            });
            //}

            //Requires that the student type field exists
            // Graduation year
            $(document).on("change", "#" + studentGradYearClickDimensionsId, function() {

                //Checks that the students grad year is this year, if so, they have to set a study area
                if ($("#" + studyAreaPreferenceClickDimensionsId)[0] != undefined) {
                    setStudyAreaRequiredLevel();
                }

                // FUTURE Probably don't need the call below because it runs too often. Form validation still works after commenting it out, and there is less code running.
                setGraduationRequiredLevelAndText();
            });

            onLoadStudentTypeFunctions();
        }

    } catch (e) {
        console.log("Failed to load scripts on click dimensions form");
        console.log(e);
    }
}));

//Call the functions that depend on the student type control but call each in a try catch as element dependencies are being added/removed dynamically
function onLoadStudentTypeFunctions() {
    try {
        setGraduationRequiredLevelAndText();
    } catch (e) {
        console.log(e);
    }

    try {
        setStudyAreaRequiredLevel();
    } catch (e) {
        console.log(e);
    }

    try {
        showStudentTypeTooltip();
    } catch (e) {
        console.log(e);
    }
}

//Sets the placeholder text on any fields we feel should have some default data
function setPlaceholderText() {

    $("#" + mobilePhoneClickDimensionsId).attr("placeholder", "04-1234-5678");
    $("#" + personalEmailClickDimensionsId).attr("placeholder", "youremail@here.com");
    var submitBtn = $("#btnSubmit");
    if (submitBtn[0] !== undefined) {
        submitBtn[0].alt = "Submit";
        submitBtn[0].title = "Submit";
    }
}

function showStudentTypeTooltipText() {
    //Clear the student grad year on change of student type

    $("#" + studentGradYearClickDimensionsId).val("-1");
    var dropdown = $("#" + studentTypeClickDimensionsId)[0];
    var tooltipDiv = $("#selectedStudentTypeDiv")[0];
    var tooltipSpan = $("#selectedStudentTypeValue")[0];

    if (dropdown[dropdown.selectedIndex].value != "-1") {

        tooltipDiv = $("#selectedStudentTypeDiv")[0].style.display = "inline-block";
        $(tooltipSpan).text(dropdown[dropdown.selectedIndex].title);
    } else {
        tooltipDiv = $("#selectedStudentTypeDiv")[0].style.display = "none";
        $(tooltipSpan).text("");
    }
}

//Appends some tool tips to the student type dropdown
function showStudentTypeTooltip() {
    var dropdown = $("#" + studentTypeClickDimensionsId)[0];

    if (dropdown !== undefined) {
        for (var i = 0; i < dropdown.options.length; i++) {

            switch (dropdown.options[i].text) {
                case "Non-school leaver":
                    dropdown.options[i].title = "You are applying for an undergraduate degree, and it has been more than three years since you completed Year 12.";
                    break;
                case "Postgraduate":
                    dropdown.options[i].title = "You are applying for a graduate certificate, postgraduate certificate, graduate diploma or masters program.";
                    break;
                case "Research":
                    dropdown.options[i].title = "You would like to undertake research (usually a Master of Research or PhD).";
                    break;
                case "School leaver":
                    dropdown.options[i].title = "You have finished Year 12 in the last three years.";
                    break;
                case "Recent school leaver":
                    dropdown.options[i].title = "You have finished Year 12 in the last three years.";
                    break;
                case "School student":
                    dropdown.options[i].title = "You are currently in years 7 to 12.";
                    break;
                case "Parent":
                    dropdown.options[i].title = "You are a parent of a school student who is currently in years 7 to 12.";
                    break;
                default:
                    dropdown.options[i].title = "Select a value";
                    break;
            }
        }
    }
}

//Ensures that the graduation required level is updated
function setGraduationRequiredLevelAndText() {
    //We have to get the hidden label field by it's parent id as click dimensions does not allocate an id to the field
    var graduationYearLabel = getLabelFromInputID(studentGradYearClickDimensionsId);

    var graduationYearDropdown = $("#" + studentGradYearClickDimensionsId)[0];
    var studentTypeDropDown = $("#" + studentTypeClickDimensionsId)[0];
    var selectedStudentTypeText = studentTypeDropDown[studentTypeDropDown.selectedIndex].text;
    var allOptions;
    if (graduationYearDropdown !== undefined) {
        if (selectedStudentTypeText == "School student") {
            $("input[value=" + studentGradYearClickDimensionsId + "]").attr("req", true);
            $(studentGradYearClickDimensionsId).prop('required', true);
            $("#required_info_f_ff6acaa6c0154567ac65d8b66bcc8a11").show();
        } else if (selectedStudentTypeText == "Parent") {
            $("input[value=" + studentGradYearClickDimensionsId + "]").attr("req", true);
            $(studentGradYearClickDimensionsId).prop('required', true);
            $("#required_info_f_ff6acaa6c0154567ac65d8b66bcc8a11").show();
        } else if (selectedStudentTypeText == "School leaver") {
            $("input[value=" + studentGradYearClickDimensionsId + "]").attr("req", true);
            $(studentGradYearClickDimensionsId).prop('required', true);
            $("#required_info_f_ff6acaa6c0154567ac65d8b66bcc8a11").show();
        } else {
            //graduationYearDropdown.style.display = "none";
            graduationYearLabel.style.display = "none";
            $("input[value=" + studentGradYearClickDimensionsId + "]").attr("req", false);
            $(studentGradYearClickDimensionsId).prop('required', false);
            $("#required_info_f_ff6acaa6c0154567ac65d8b66bcc8a11").addClass("hide");
        }
    }

    //This is optional and support across all browsers is unknown, works in all major browsers past 2015.
    try {
        allOptions = document.querySelectorAll("option");
        for (i = 0; i < allOptions.length; i++) {
            if (allOptions[i].parentElement.id == studentGradYearClickDimensionsId) {
                // CHANGES: Changed this into an if else block based from current year to avoid updating.
                var yearOptionNumber = parseInt($(allOptions[i]).text(), 10);
                if (yearOptionNumber < currentYear) {
                    // Past years
                    if (selectedStudentTypeText == "School student" || selectedStudentTypeText == "Parent") {
                        allOptions[i].disabled = true;
                        allOptions[i].style.display = "none";
                    } else if (selectedStudentTypeText == "School leaver") { //Should we just make this "else" to hide current year from postgrads, NSL, research?
                        allOptions[i].disabled = false;
                        allOptions[i].style.display = "";
                    }
                } else {
                    // Current and future years                    
                    if (selectedStudentTypeText == "School student" || selectedStudentTypeText == "Parent") {
                        allOptions[i].disabled = false;
                        allOptions[i].style.display = "";
                    } else if (selectedStudentTypeText == "School leaver") {
                        allOptions[i].disabled = true;
                        allOptions[i].style.display = "none";
                    }
                }
            }
        }
    } catch (e) {

        console.log(e);
    }
}

// ClickDimensions does not assign labels Id's so we need to retrieve all the span elements on the page and identify the one with the graduate text
// we assign it an ID to ensure that we can re use it later (after changing the text)
function getLabelFromInputID(inputID) {
    // This was fragile and didn't work if anyone changes the label.
    // MER | Standard Web Content form | Brisbane in production is a current example.
    // CHANGES Changed this code to select using the ID variables at the top of this javascript.

    var parentDiv = $("#" + inputID).parent().parent().parent();
    // We needed to go up 3 levels
    // now need to find the span label child of the above element.
    var labelSpan = $("div>span", parentDiv)[0];
    if (labelSpan != undefined) {
        // Just in case it wasn't found
        return labelSpan;
    }
}

//If acu_audience = 'school student' AND 'year_grd_school'<> current 
//Then study area preference 1 is mandatory. 
// Otherwise study area preference 1 is not mandatory.
function setStudyAreaRequiredLevel() {
    var graduationYearDropdown = $("#" + studentGradYearClickDimensionsId)[0];
    var selectedGraduationYearText = graduationYearDropdown[graduationYearDropdown.selectedIndex].text;
    var studentTypeDropDown = $("#" + studentTypeClickDimensionsId)[0];
    var selectedStudentTypeText = studentTypeDropDown[studentTypeDropDown.selectedIndex].text;
    var currentYear = (new Date()).getFullYear().toString();
    var studyPreferenceLabel = getLabelFromInputID(studyAreaPreferenceClickDimensionsId);
    var labelText = "Study area preference" + (singleCampus ? "" : " 1");
    if (graduationYearDropdown !== undefined && studentTypeDropDown !== undefined) {
        if ((selectedStudentTypeText == "School student" || selectedStudentTypeText == "Parent") && (selectedGraduationYearText == currentYear)) {
            // console.log("School student graduating this year");
            $("input[value=" + studyAreaPreferenceClickDimensionsId + "]").attr("req", true);
        } else if (selectedStudentTypeText == "School leaver" || selectedStudentTypeText == "Non-school leaver" || selectedStudentTypeText == "Postgraduate" || selectedStudentTypeText == "Research") {

            $("input[value=" + studyAreaPreferenceClickDimensionsId + "]").attr("req", true);

        } else if ((selectedStudentTypeText == "School student" || selectedStudentTypeText == "Parent") && (selectedGraduationYearText != currentYear)) {
            $("input[value=" + studyAreaPreferenceClickDimensionsId + "]").attr("req", false);
        } else if (selectedStudentTypeText == "" || studentTypeDropDown.value == "-1") {
            $("input[value=" + studyAreaPreferenceClickDimensionsId + "]").attr("req", false);
        }
    } else if (graduationYearDropdown == undefined && studentTypeDropDown !== undefined) {
        $("input[value=" + studyAreaPreferenceClickDimensionsId + "]").attr("req", false);
    }
}

function setStudyAreaByCampus(campusPreferenceClickDimensionsId, studyAreaPreferenceFieldClickDimensionsId) {
    $("#" + studyAreaPreferenceFieldClickDimensionsId).val("-1");
    var campus = $("#" + campusPreferenceClickDimensionsId)[0];
    var campusSelectedValue = $(campus[campus.selectedIndex]).text();
    if (campusSelectedValue.replace(/s/g, '').length) { // Cater for the case that the string is all spaces / blank. If statement ignores the blank case.
        setStudyAreaDropdownValuesBySelectedControl(campusSelectedValue, studyAreaPreferenceFieldClickDimensionsId);
    }
}

//Accepts a given campus name and the desired preference control. Removes/Adds elements to the control based on the configuration in the campus object
function setStudyAreaDropdownValuesBySelectedControl(campusName, preferenceControl) {
    var allOptions = document.querySelectorAll("option");
    var studentTypeDropDown = $("#" + studentTypeClickDimensionsId)[0];
    var selectedStudentTypeText = studentTypeDropDown[studentTypeDropDown.selectedIndex].text;
    var campus = getCampusObjectByName(campusName);
    var studyAreaIterating;

    /*  Allow Research to have specific study areas.
     *   The below logic works but may be hard to follow, so here is a description.
     *   Goal is to use "Undergraduate" in the case of:
     *       School Leaver,
     *       Non-School Leaver, 
     *       and School Student,
     *       Parent
     *   We do this by catching the cases of Research and Postgraduate.
     *   Then everything else (SL/NSL/SS/Parent) is caught by the 'default' and changed to "Undergraduate".
     */
    switch (selectedStudentTypeText) {
        case "Research":
            break; // Do nothing.
        case "Postgraduate":
            break; // Do nothing
        default: //SL/NSL/SS/Parent
            selectedStudentTypeText = "Undergraduate"; // Use undergraduate category.
            break;
    }
    // Filter study areas
    if (campus !== undefined && campus != null && studentTypeDropDown.value != "-1") {
        for (var i = 0; i < allOptions.length; i++) {
            studyAreaIterating = $(allOptions[i]).text();
            if (allOptions[i].parentElement.id == preferenceControl) {
                // The switch below has a default dealing with whenever the case condition text exactly matches the data element.
                switch (studyAreaIterating) {
                    case "Humanities and social sciences":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].HumanitiesSocialSciences);
                        break;
                    case "Creative arts":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].CreativeArts);
                        break;
                    case "Allied health": // This changed in 2019
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].AlliedHealth);
                        break;
                    case "Nursing, midwifery and paramedicine":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].NursingMidwiferyParamedicine);
                        break;
                    case "Information technology":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].InformationTechnology);
                        break;
                    case "Global studies and international development": // renamed label in 2020.
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].GlobalStudies);
                        break;
                    case "Public health and administration":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].PublicHealthAndAdministration);
                        break;
                    case "Sport and exercise science":
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].SportAndExerciseScience);
                        break;
                    case "Professional education": // New study area
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].ProfessionalEducation);
                        break;
                    case "Youth work and community development": // New study area 2020.
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].YouthWorkCommunityDevelopment);
                        break;
                    case "Nutrition and biomedical science": // Added in 2019
                        toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText].NutritionBiomedicalScience);
                        break;
                    default: // When the study area is one word and the dropdown is identical to the study area key within the campus data structure.
                        // The 'If' statement below ignores the blank case. 
                        if (studyAreaIterating.replace(/s/g, '').length) {
                            toggleDropdownOption(allOptions[i], campus[selectedStudentTypeText][studyAreaIterating]);
                        }
                        break;
                }
            }
        }
    }
}

//Multi browser supported way of hiding a dropdown item - IE has no supported method of hiding an option element without possibly breaking clickdimensions posted forms
function toggleDropdownOption(control, visible) {

    if (visible) {
        control.style.display = "";
        control.disabled = false;
    } else {
        control.style.display = "none";
        control.disabled = true;
    }
}

//Ensure that we're dealing with a number
function checkIsNumber(myEvento) {
    if ((myEvento.charCode >= 48 && myEvento.charCode <= 57) || myEvento.keyCode == 9 || myEvento.keyCode == 10 || myEvento.keyCode == 13 || myEvento.keyCode == 8 || myEvento.keyCode == 116 || myEvento.keyCode == 46 || (myEvento.keyCode <= 40 && myEvento.keyCode >= 37)) {
        dato = true;
    } else {
        dato = false;
    }
    return dato;
}

//Assigns some id's to the study pref and study pref description rows so we can reshuffle elements later
function setStudyRowIds(control) {

    var studyPrefDescriptionRow = control.parentElement.parentElement.parentElement.parentElement;
    var studyPrefRow = $("#" + studyAreaPreferenceClickDimensionsId)[0] //.parentElement.parentElement.parentElement.parentElement;
    studyPrefDescriptionRow.id = "studyPreferenceDescriptionRow";
    studyPrefRow.id = "studyPrefRow";
}

function getCampusObjectByName(campusName) {
    var campus;
    Object.keys(Campuses).forEach(function(key) {
        if (Campuses[key].Name == campusName) {
            // console.log("Campus = " + campusName);
            campus = Campuses[key];
        }
    });

    return campus;
}

// CHANGES New function to hide campus in 2 cases.
function hideCampus(audience) {
    var campus1 = $("#" + campusPreferenceClickDimensionsId)[0];
    var campus2 = $("#" + campusPreference2ClickDimensionsId)[0];
    // var blankCampusOptionRef;
    try {
        allOptions = document.querySelectorAll("option");
    } catch (e) {
        console.log(e);
    }
    // FUTURE: Should the below code remove the option OR return true/false to allow another function to remove it or hide all the study area options?
    for (var i = 0; i < allOptions.length; i++) {
        /* console.info(allOptions[i].parentElement.id);  //debugging line */
        if (allOptions[i].parentElement.id == campusPreferenceClickDimensionsId || allOptions[i].parentElement.id == campusPreference2ClickDimensionsId) {
            if (allOptions[i].text.replace(/s/g, '').length == 0) { // Find the option which is all spaces / blank. 
                blankCampusOptionRef = allOptions[i];
            }
            if ($(allOptions[i]).text() == "Blacktown") {
                if (audience == "Research") {
                    // Code to hide the Blacktown campus option.
                    toggleDropdownOption(allOptions[i], false);
                    // Check if online is currently selected before clearing it
                    try {
                        if (blankCampusOptionRef.parentElement[blankCampusOptionRef.parentElement.selectedIndex].text == "Blacktown") {
                            blankCampusOptionRef.parentElement.selectedIndex = -1; //Clear the selected campus in case they selected Online already.
                        }
                    } catch (e) {
                        // There is no campus selected currently.
                    }
                } else {
                    // Code to show the Online option.
                    toggleDropdownOption(allOptions[i], true);
                }
            } else {
                if ($(allOptions[i]).text() == "Adelaide") {
                    switch (audience) {
                        case "School student": // These four audiences comprise the undergraduate level
                        case "School leaver":
                        case "Non-school leaver":
                        case "Parent":
                            // Hide the Adelaide option.
                            toggleDropdownOption(allOptions[i], false);
                            try {
                                if (blankCampusOptionRef.parentElement[blankCampusOptionRef.parentElement.selectedIndex].text == "Adelaide") {
                                    blankCampusOptionRef.parentElement.selectedIndex = -1; //Clear the selected campus in case they selected Adelaide already.
                                }
                            } catch (e) {
                                // There is no campus selected currently.
                            }
                            break;
                        default:
                            toggleDropdownOption(allOptions[i], true);
                    }
                }
            }
        }
    }
}

// Contains all possible campuses and available course combinations by undergrad/postgrad
// FUTURE: change data below so that only "true" values are needed (sparse matrix).
// STUDY AREAS CHECKED: 01/04/2020
var Campuses = {
    Adelaide: {
        Name: "Adelaide",
        Undergraduate: {
            Theology: false,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: false,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: false,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: false,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Ballarat: {
        Name: "Ballarat",
        Undergraduate: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Blacktown: {
        Name: "Blacktown",
        Undergraduate: {
            Theology: false,
            Philosophy: false,
            Business: true,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: true,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: false,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: false,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: false,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Brisbane: {
        Name: "Brisbane",
        Undergraduate: {
            Theology: true,
            Philosophy: true,
            Business: true,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: true,
            GlobalStudies: true,
            CreativeArts: true,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: true,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: false,
            Business: true,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: true,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Canberra: {
        Name: "Canberra",
        Undergraduate: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            Psychology: false,
            ProfessionalEducation: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Melbourne: {
        Name: "Melbourne",
        Undergraduate: {
            Theology: true,
            Philosophy: true,
            Business: true,
            InformationTechnology: true,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: true,
            GlobalStudies: true,
            CreativeArts: true,
            AlliedHealth: true,
            PublicHealthAndAdministration: true,
            NutritionBiomedicalScience: true,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: true,
            YouthWorkCommunityDevelopment: true
        },
        Postgraduate: {
            Theology: true,
            Philosophy: false,
            Business: true,
            InformationTechnology: true,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: true,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: true,
            Psychology: true,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: true,
            GlobalStudies: false,
            CreativeArts: true,
            AlliedHealth: true,
            PublicHealthAndAdministration: true,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: true,
            Psychology: true,
            YouthWorkCommunityDevelopment: false
        }
    },
    NorthSydney: {
        Name: "North Sydney",
        Undergraduate: {
            Theology: false,
            Philosophy: false,
            Business: true,
            InformationTechnology: true,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: true,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: true,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: false,
            Philosophy: false,
            Business: true,
            InformationTechnology: true,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: true,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: true,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: true,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
    Strathfield: {
        Name: "Strathfield",
        Undergraduate: {
            Theology: true,
            Philosophy: true,
            Business: true,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: true,
            GlobalStudies: true,
            CreativeArts: true,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: true,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: true,
            Psychology: true,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: true,
            Philosophy: true,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: true,
            Psychology: true,
            YouthWorkCommunityDevelopment: false
        }
    },
    Online: {
        Name: "Online",
        Undergraduate: {
            Theology: false,
            Philosophy: false,
            Business: true,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: false,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Postgraduate: {
            Theology: true,
            Philosophy: true,
            Business: true,
            InformationTechnology: false,
            Law: true,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: true,
            PublicHealthAndAdministration: true,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: true,
            NursingMidwiferyParamedicine: true,
            ProfessionalEducation: true,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        },
        Research: {
            Theology: false,
            Philosophy: false,
            Business: false,
            InformationTechnology: false,
            Law: false,
            Teaching: true,
            HumanitiesSocialSciences: false,
            GlobalStudies: false,
            CreativeArts: false,
            AlliedHealth: false,
            PublicHealthAndAdministration: false,
            NutritionBiomedicalScience: false,
            SportAndExerciseScience: false,
            NursingMidwiferyParamedicine: false,
            ProfessionalEducation: true,
            Psychology: false,
            YouthWorkCommunityDevelopment: false
        }
    },
}


// script end