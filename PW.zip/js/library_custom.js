$(document).ready(function() {
    $("#headerSearchTextBox").attr("placeholder", "Search for books & articles ...");
    $("#searchTextBox").attr("placeholder", "Search in library website ...");
    $(".search__input").attr("placeholder", "Search for books & articles ...");

    $('.ls .li_select').change(function() {
        var k = $(this).val();
        //console.log(k);

        if (k == 'Booksandarticle') {
            $(".l_input").attr("placeholder", "Search for books & articles ...");
        } else if (k == 'Librarywebsite') {
            $(".l_input").attr("placeholder", "Search in library website ...");
        } else if (k == 'Studentportal') {
            $(".l_input").attr("placeholder", "Search in student portal ...");
        }

    });


    $('.li_select').change(function() {
        var k = $(this).val();
        //console.log(k);

        if (k == 'Booksandarticle') {
            $(".search__input").attr("placeholder", "Search for books & articles ...");
        } else if (k == 'Librarywebsite') {
            $(".search__input").attr("placeholder", "Search in library website ...");
        } else if (k == 'Studentportal') {
            $(".search__input").attr("placeholder", "Search in student portal ...");
        }


    });

    $(".anchr_links a").click(function() {

        $(this).parents(".container").find(".a_p").removeClass("a_p");



        var a_content = $(this).attr("href");
        console.log(a_content);

        $(this).parents(".container").find(a_content).addClass("a_p");

        var pos = $(this).parents(".container").find(".a_p").position();

        goToByScroll($(a_content));
        console.log(pos);


        function goToByScroll(element) {
            var topval;

            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 70;

            } else {

                topval = 70;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
            console.log(topval)
        }





    });







    $(".anchr_quick_links .arrow-link").click(function() {

        var a_content = $(this).attr("href");
        console.log(a_content);

        goToByScroll($(a_content));

        function goToByScroll(element) {
            var topval;

            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 70;

            } else {

                topval = 180;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
            console.log(topval)
        }

    });




});