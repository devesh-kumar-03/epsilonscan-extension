// $(document).ready(function() {



//     //showHideArrow();
//     // var parent = $(".owl-carousel").parent().attr('id');
//     // alert(parent);




//     function showProjectsbyCat(parentId, cat) {

//         var $owl = $('.owl-carousel').owlCarousel({
//             items: 4,
//             loop: false
//         });


//         function showHideArrow() {
//             $('.owl-carousel').each(function() {

//                 if ($(this).find(".owl-item").length < 4) {
//                     $(this).find(".owl-nav").hide();
//                     console.log($(this).find(".owl-item").length);
//                 } else {
//                     $(this).find(".owl-nav").show();
//                 }

//             });

//         }

//         $owl.trigger('refresh.owl.carousel');


//         // If there is only three slides
//         // if (totalItems == 4) {
//         //     $(".owl-nav").hide();

//         // } else {
//         //     $(".owl-nav").show();
//         // }


//         //var owl = $(".filter").next(".owl-carousel").data('owlCarousel');
//         if (cat == 'all') {
//             $('#' + parentId).find('.projects-hidden .project').each(function() {
//                 var owl = $('#' + parentId).find(".owl-carousel").data('owl.carousel')
//                 elem = $(this).parent().html();
//                 owl.add(elem);
//                 $(this).parent().remove();
//                 $owl.trigger('refresh.owl.carousel');
//             });
//         } else {
//             $('#' + parentId).find('.projects-hidden .project.' + cat).each(function() {
//                 var owl = $('#' + parentId).find(".owl-carousel").data('owl.carousel');
//                 elem = $(this).parent().html();
//                 owl.add(elem);
//                 $(this).parent().remove();
//                 $owl.trigger('refresh.owl.carousel');
//             });

//             $('#' + parentId).find('.owl-carousel .project:not(.project.' + cat + ')').each(function() {
//                 var owl = $('#' + parentId).find(".owl-carousel").data('owl.carousel');
//                 targetPos = $(this).parent().index();
//                 elem = $(this).parent();
//                 $(elem).clone().appendTo($('#' + parentId).find('.projects-hidden'));
//                 owl.remove(targetPos);
//                 $owl.trigger('refresh.owl.carousel');
//             });



//         }

//         $('.owl-carousel').owlCarousel();
//         showHideArrow();

//     }




//     //Click event for filters
//     $('.filter a').click(function(e) {
//         //e.preventDefault();

//         var parentId = $(this).parent().parent().attr('id');
//         // var total = $(".owl-carousel .owl-stage .active");
//         // var slidelength = parentId.total.length;

//         // alert(slidelength);


//         cat = $(this).attr('ID');
//         $(this).addClass('btn-active').siblings().removeClass('btn-active');;
//         showProjectsbyCat(parentId, cat);
//         //alert('filtering' + cat);
//     });

//     $('.filter ul li a').click(function(e) {
//         //e.preventDefault();

//         var campus = $(this).text();
//         //alert(campus);

//         var parentId = $(this).parent().parent().parent().parent().attr('id');

//         $(".dropdown button").text(campus);


//         cat = $(this).attr('ID');
//         $(this).removeClass('btn-active');;
//         showProjectsbyCat(parentId, cat);
//         //alert('filtering' + cat);
//     });

//     //Initialize owl carousel
//     $('.owl-carousel').owlCarousel({
//         items: 4,
//         loop: false,
//         center: false,
//         margin: 30,
//         nav: true,
//         responsiveClass: true,
//         responsive: {
//             0: {
//                 items: 1,

//             },
//             728: {
//                 items: 3,

//             },
//             1100: {
//                 items: 4,


//             }
//         }
//     });


// });