$(document).ready(function() {
    $(".menu-list").setup_navigation();
});

$(function() {
    $('.nav').setup_navigation();
});



$.fn.setup_navigation = function(settings) {

    settings = jQuery.extend({
        menuHoverClass: 'show-menu',
    }, settings);

    // Add ARIA role to menubar and menu items
    $(this).attr('role', 'menubar').find('li').attr('role', 'menuitem');

    var top_level_links = $(this).find('> li > a');

    // Added by Terrill: (removed temporarily: doesn't fix the JAWS problem after all)
    // Add tabindex="0" to all top-level links 
    // Without at least one of these, JAWS doesn't read widget as a menu, despite all the other ARIA
    //$(top_level_links).attr('tabindex','0');

    // Set tabIndex to -1 so that top_level_links can't receive focus until menu is open
    $(top_level_links).next('.mega-menu__content')
        .attr('data-test', 'true')
        .attr({ 'aria-hidden': 'true', 'role': 'menu' })
        .find('a')
        .attr('tabIndex', -1);

    // Adding aria-haspopup for appropriate items
    $(top_level_links).each(function() {
        if ($(this).next('ul').length > 0)
            $(this).parent('li').attr('aria-haspopup', 'true');
    });


    $(top_level_links).focus(function() {
        $(this).closest('.mega-menu__content')
            // Removed by Terrill 
            // The following was adding aria-hidden="false" to root ul since menu is never hidden
            // and seemed to be causing flakiness in JAWS (needs more testing) 
            // .attr('aria-hidden', 'false') 
            .find('.' + settings.menuHoverClass)
            .attr('aria-hidden', 'true')
            .removeClass(settings.menuHoverClass)
            .find('a')
            .attr('tabIndex', -1);
        $(this).next('.mega-menu__content')
            .attr('aria-hidden', 'false')
            .addClass(settings.menuHoverClass)
            .find('a').attr('tabIndex', 0);
    });


    // Hide menu if click or focus occurs outside of navigation
    $(this).find('a').last().keydown(function(e) {
        if (e.keyCode == 9) {
            // If the user tabs out of the navigation hide all menus
            $('.' + settings.menuHoverClass)
                .attr('aria-hidden', 'true')
                .removeClass(settings.menuHoverClass)
                .find('a')
                .attr('tabIndex', -1);
        }
    });
    $(document).click(function() { $('.' + settings.menuHoverClass).attr('aria-hidden', 'true').removeClass(settings.menuHoverClass).find('a').attr('tabIndex', -1); });

    $(this).click(function(e) {
        e.stopPropagation();
    });
}