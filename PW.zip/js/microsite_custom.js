$(document).ready(function() {



    $(".policy_meta_data table").removeAttr("data-tablesaw-mode", "stack");



    artslider();

    function artslider() {
        var artslider = $(".collection_bar").attr('id');
        console.log(artslider);


        $('#' + artslider).each(function() {
            var Bannerart = $(".collection_bar");

            $(Bannerart).each(function() {



                $(this).owlCarousel({
                    items: 1,
                    loop: true,
                    pagination: true,
                    nav: true,
                    center: true,


                    //dotsContainer: '.customDots',

                });




                var currentItem = $('#' + artslider).find(".owl-dots .active").index();
                console.log(currentItem);

                var items = $('#' + artslider).find(".owl-dots .owl-dot").length;
                console.log(items);


                $('#' + artslider).parent(".nm").find('.counter').html((currentItem + 1) + " / " + items);

                if (items < 2) {

                    $('#' + artslider).find('.nxt-slide').hide();
                    $('#' + artslider).find('.prev-slide').hide();
                    $('#' + artslider).find(".control").hide();
                    $('#' + artslider).find('.counter').hide();
                }



            });


            $(Bannerart).on('changed.owl.carousel', function(event) {


                var par = $(".collection_bar").attr('id');
                //console.log(par);

                var currentItem = $('#' + artslider).find(".owl-dots .active").index();
                //console.log(currentItem);


                var items = $('#' + artslider).find(".owl-dots .owl-dot").length;
                //console.log(items);


                $(this).parent(".nm").find('.counter').html((currentItem + 1) + " / " + items);

                //console.log(event);

            });

        })

    }



    // footnote js start


    $("a[rel$='footnote']").click(function() {

        $(this).each(function() {
            var footnote_content = $(this).attr("href");

            goToByScroll($(footnote_content));

            function goToByScroll(element) {
                var topval;

                if ($(".header__global").hasClass("js-is-sticky")) {
                    topval = 170;

                } else {

                    topval = 170;
                }
                if ($(window).width() < 1024) {
                    topval = 50;
                }
                $('html,body').animate({
                        scrollTop: element.offset().top -= topval
                    },
                    'slow');
                //console.log(topval, element.offset().top);
            }
        })

    })


    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    })



    // footnote js end




    // rich text scroll function start






    $('.scroll_text a[name]').each(function() {
        var ext = $(this).attr('name');

        $(this).attr('id', ext);
    });







    $(".scroll_text").find("a").click(function() {

        var name_content = $(this).attr("href");

        console.log(name_content);

        goToByScroll($(name_content));

        function goToByScroll(element) {
            var topval;
            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 70;
            } else {
                topval = 170;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
        }

    });
    // rich text scroll function end


    $(".alpha_search a").click(function() {

        $(".alpha_search a").removeClass("alpha");
        $(this).addClass("alpha");


    })




});