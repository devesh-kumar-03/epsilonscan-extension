$(document).ready(function() {


    // ----------------- staff giving form validation start ----------------- >

    $("#btnsubmitstaff").click(function() {

        console.log("form clicked");

        //date validation start
        $(function() {
            var dtToday = new Date();

            var month = dtToday.getMonth() + 1;
            var day = dtToday.getDate() + 1;
            var year = dtToday.getFullYear();
            if (month < 10)
                month = '0' + month.toString();
            if (day < 10)
                day = '0' + day.toString();

            var maxDate = year + '-' + month + '-' + day;
            $('#endDateInput').attr('min', maxDate);
        });

        function setvalue() {
            isFutureDate($('#endDateInput').val());
        }

        function isFutureDate(idate) {
            var today = new Date().getTime(),
                idate = idate.split("-");

            var date = new Date(idate[0], idate[1] - 1, idate[2]).getTime();
            var result = (today - date) < 0;
            if (result == true) {
                $("#acu_end_date").val(idate[1] + "/" + idate[2] + "/" + idate[0]);
                $("#enddatealert").hide();
                $('#endDateInput').removeClass("alert_form_field");
            } else {
                //alert("Please enter future date");
                $("#enddatealert").show();
                $('#endDateInput').addClass("alert_form_field");
                $('#endDateInput').val('');
                $("#acu_end_date").val('');

            }
        }
        //date validation end

        //Fund validation start
        function fundcheck() {

            var fundvalule = $('#acu_fund_number').find('option:selected').val();
            if (fundvalule === 'Please select') {
                $("#fundalert").show();
                $('#acu_fund_number').addClass("alert_form_field");
            } else {
                $("#fundalert").hide();
                $('#acu_fund_number').removeClass("alert_form_field");
            }
        }
        //Fund validation end

        // amount validation start
        function amountcheck() {
            var amountvalue = $("#acu_amount").val();
            if (amountvalue == '') {
                $("#amountalert").show();
                $("#acu_amount").addClass("alert_form_field");
            } else {
                $("#amountalert").hide();
                $("#acu_amount").removeClass("alert_form_field");
            }
        }
        // amount validation end

        //frequency radio button validation start
        function frequency() {
            var freq = $('#frequency .checkbox input[type="radio"]:checked').length
            if (freq === 0) {
                $("#frequency .custom-form__label").addClass("radio_alert");
                $("#frequency_alart").show();
                return false;
            } else {
                $("#frequency .custom-form__label").removeClass("radio_alert");
                $("#frequency_alart").hide();
            }
        }
        //frequency radio button validation end

        //Gift Acknowledgement radio button validation start
        function giftAcknowledgement() {
            var gift = $('#giftAcknowledgement .checkbox input[type="radio"]:checked').length
            if (gift === 0) {
                $("#giftAcknowledgement .custom-form__label").addClass("radio_alert");
                $("#ackalert").show();
                return false;
            } else {
                $("#giftAcknowledgement .custom-form__label").removeClass("radio_alert");
                $("#ackalert").hide();
            }
        }
        //Gift Acknowledgement radio button validation end


        // calling function on click

        setvalue()
        amountcheck()
        fundcheck()
        frequency()
        giftAcknowledgement()


    });

    // Email validation start
    function emailvalidate() {
        var email = $("#alt_emailaddress").val();
        var re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm;
        if (email == "") {
            $('#alternate_email').hide();
            $("#alt_emailaddress").removeClass("alert_form_field");
        } else if (re.test(email)) {
            //console.log("valid email")
            $('#alternate_email').hide();
            $("#alt_emailaddress").removeClass("alert_form_field");
        } else {
            //console.log("not valid email");
            $("#alt_emailaddress").addClass("alert_form_field");
            $('#alternate_email').show();
        }

    }
    // Email validation end

    $("#alt_emailaddress").on('blur', function() {
        emailvalidate()

    });


    // -----------------  staff giving form validation end ----------------- >


    $(".anchr_quick_links .arrow-link").click(function() {

        var a_content = $(this).attr("href");
        //console.log(a_content);

        goToByScroll($(a_content));

        function goToByScroll(element) {
            var topval;

            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 70;

            } else {

                topval = 180;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
            //console.log(topval)
        }

    });

    $(".anchr_links").find("a").click(function() {

        //$(this).parents(".container").find(".a_p").removeClass("a_p");

        var a_content = $(this).attr("href");
        //console.log(a_content);

        // $(this).parents(".container").find(a_content).addClass("a_p");

        //var pos = $(this).parents(".container").find(".a_p").position();

        goToByScroll($(a_content));

        function goToByScroll(element) {
            var topval;

            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 170;

            } else {

                topval = 170;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
            //console.log(topval, element.offset().top);
        }



        //console.log(pos);


    });



    $('.scroll_text a').each(function() {
        var extp = $(this).attr('href');
        //console.log(extp.replace(/\./g, '_'));

        var np = extp.replace(/\./g, '_');

        $(this).attr('href', np);
    });

    $('.scroll_text h2, .scroll_text h3, .scroll_text h4').each(function() {
        var extp = $(this).attr('id');
        //console.log(extp.replace(/\./g, '_'));

        var np = extp.replace(/\./g, '_');

        $(this).attr('id', np);
    });



    $(".scroll_text").find("a").click(function() {

        var name_content = $(this).attr("href");

        console.log(name_content);

        goToByScroll($(name_content));

        function goToByScroll(element) {
            var topval;
            if ($(".header__global").hasClass("js-is-sticky")) {
                topval = 70;
            } else {
                topval = 170;
            }
            if ($(window).width() < 1024) {
                topval = 50;
            }
            $('html,body').animate({
                    scrollTop: element.offset().top -= topval
                },
                'slow');
        }

    });








});