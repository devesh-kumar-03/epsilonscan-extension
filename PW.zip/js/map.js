var latitude = document.getElementById('latitude').value;
var longitude = document.getElementById('longitude').value;

var startPosition = new google.maps.LatLng(parseFloat(latitude), parseFloat(longitude));//{ lat: latitude, lng: longitude };
var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 11,
    center: startPosition
});
var marker = new google.maps.Marker({
    position: startPosition,
    map: map
});
//Resize Function
google.maps.event.addDomListener(window, "resize", function () {
    var center = map.getCenter();
    google.maps.event.trigger(map, "resize");
    map.setCenter(center);
});
