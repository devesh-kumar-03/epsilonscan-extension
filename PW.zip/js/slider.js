$(document).ready(function() {

    videoslider();

    function videoslider() {
        var videoslider = $(".video-carousel").attr('id');

        $('#' + videoslider).each(function() {

            // var itemscount = $(this).find(".owl-item").length;
            // console.log(itemscount)

            // if (itemscount <= 2) {
            //     $(this).find('.holder .nxt-slide-video').hide();
            //     $(this).find('.holder .prev-slide-video').hide();

            // } else {
            //     $(this).find('.holder .nxt-slide-video').show();
            //     $(this).find('.holder .prev-slide-video').show();
            // }


            // slider code

            var VideoOwl = $(".video-slider")

            $(VideoOwl).each(function() {
                $(this).owlCarousel({
                    items: 1,
                    loop: false,
                    autoplay: false,
                    video: true,
                    pagination: false,

                });

                $(this).parents(".video-carousel").find(".holder .text-holder-video .description").hide();
                $(this).parents(".video-carousel").find(".holder .text-holder-video .description").eq(0).show();

                var currentItem = $(this).find(".owl-item").index();
                //console.log(currentItem);

                var items = $(this).find(".owl-item").length;
                console.log(items);

                if (items < 2) {
                    $(this).parents(".video-carousel").find('.holder .nxt-slide-video').hide();
                    $(this).parents(".video-carousel").find('.holder .prev-slide-video').hide();

                } else {
                    $(this).parents(".video-carousel").find('.holder .nxt-slide-video').show();
                    $(this).parents(".video-carousel").find('.holder .prev-slide-video').show();
                }

                $(this).parents(".video-carousel").find('.counter').html((currentItem + 1) + " / " + items)










            });





            $(VideoOwl).on('changed.owl.carousel', function(event) {
                var par = $(this).parents(".video-carousel").attr('id');
                //console.log(par);

                var videolenght = $(this).find(".owl-item").length;
                //console.log(videolenght);

                var currentItem = event.item.index;
                //console.log(currentItem);

                var items = event.item.count;



                //window.location.hash = currentItem + 1;


                $(this).parents(".video-carousel").find(".holder .text-holder-video .description").hide();
                $(this).parents(".video-carousel").find(".holder .text-holder-video .description").eq(currentItem).show();

                $(this).parents(".video-carousel").find('.counter').html((currentItem + 1) + " / " + items)

                //console.log(event);

            });

            $('.nxt-slide-video').click(function() {
                var videoslider = $(this).parents(".video-carousel").attr('id');

                $('#' + videoslider).find('.video-slider').trigger('next.owl.carousel');
            });

            $('.prev-slide-video').click(function() {
                var videoslider = $(this).parents(".video-carousel").attr('id');
                $('#' + videoslider).find('.video-slider').trigger('prev.owl.carousel');
            });


        });

    }




    bannerslider();

    function bannerslider() {

        var bannerslider = $(".banner__image__cta").attr('id');
        //console.log(bannerslider);



        $('#' + bannerslider).each(function() {
            // slider code

            var BannerOwl = $(".banner-slider");
            console.log(BannerOwl.length);


            $(BannerOwl).each(function() {

                var bann = $(this).parents("section").attr('id');
                console.log(bann);

                $(this).owlCarousel({
                    items: 1,
                    loop: false,
                    autoplay: false,
                    //video: true,
                    pagination: true,
                    //dotsContainer: '.customDots',

                });



                var currentItem = $(this).find(".owl-item").index();
                //console.log(currentItem);

                var items = $(this).find(".owl-item").length;
                //console.log(items);

                $(this).parents(".banner__image__cta").find('.counter').html((currentItem + 1) + " / " + items);






            });

            $(BannerOwl).on('changed.owl.carousel', function(event) {
                var par = $(this).parents(".banner__image__cta").attr('id');
                //console.log(par);

                var videolenght = $(this).find(".owl-item").length;
                //console.log(videolenght);

                var currentItem = event.item.index;
                //console.log(currentItem);

                var items = event.item.count;

                $(this).parents(".banner__image__cta").find('.counter').html((currentItem + 1) + " / " + items)

                //console.log(event);

            });

            $('.nxt-slide').click(function() {
                var bannerslider = $(this).parents(".banner__image__cta").attr('id');

                $('#' + bannerslider).find('.banner-slider').trigger('next.owl.carousel');
            });

            $('.prev-slide').click(function() {
                var bannerslider = $(this).parents(".banner__image__cta").attr('id');
                $('#' + bannerslider).find('.banner-slider').trigger('prev.owl.carousel');
            });


        });

    }








    $('#nxt-slide').click(function() {
        $('.banner-slider').trigger('next.owl.carousel');
    });

    $('#prev-slide').click(function() {
        $('.banner-slider').trigger('prev.owl.carousel');
    });

    $('#nxt-slide-sand').click(function() {
        $('.banner-slider-sand').trigger('next.owl.carousel');
    });

    $('#prev-slide-sand').click(function() {
        $('.banner-slider-sand').trigger('prev.owl.carousel');
    });




    downloadslider();

    function downloadslider() {
        var downloadslider = $(".owl-carousel-progressbar").attr('id');

        $('#' + downloadslider).each(function() {

            // slider code

            var downloadoOwl = $(".owl-carousel-download")

            $(downloadoOwl).each(function() {
                $(this).owlCarousel({
                    items: 1,
                    //loop: true,
                    autoplay: false,

                    //center: true,
                    pagination: true,
                    nav: true,


                    margin: 40,
                    responsiveClass: true,



                });

                $(this).parents(".owl-carousel-progressbar").find(".text-holder .description").hide();
                $(this).parents(".owl-carousel-progressbar").find(".text-holder .description").eq(0).show();

                var currentItem = $(this).find(".owl-item").index();
                //console.log(currentItem);

                var items = $(this).find(".owl-item").length;
                //console.log(items);

                $(this).parents(".owl-carousel-progressbar").find('.counter').html((currentItem + 1) + " / " + items)


            });



            $(downloadoOwl).on('changed.owl.carousel', function(event) {
                var par = $(this).parents(".video-carousel").attr('id');
                //console.log(par);

                // var videolenght = $(this).find(".owl-item").length;
                // console.log(videolenght);

                var currentItem = event.item.index;
                //console.log(currentItem);

                var items = event.item.count;


                $(this).parents(".owl-carousel-progressbar").find(".text-holder .description").hide();
                $(this).parents(".owl-carousel-progressbar").find(".text-holder .description").eq(currentItem).show();

                $(this).parents(".owl-carousel-progressbar").find('.counter').html((currentItem + 1) + " / " + items)

                //console.log(event);




            });




        });

    }





});