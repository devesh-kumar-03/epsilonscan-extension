var app = new Vue({
    el: ".site-search",
    data: {
        searchString: "",

        // hardcoded for simplicity
        // should use ajax
        articles: [{
                title: "Arts and humanities",
                url: "#"
            },
            {
                title: "Business",
                url: "#"
            },
            {
                title: "Creative arts & communications",
                url: "#"
            },
            {
                title: "Teaching & professional education",
                url: "#"
            },
            {
                title: "Sport and exercise science",
                url: "#"
            },
            {
                title: "Health sciences & allied health",
                url: "#"
            },
            {
                title: "Information technology",
                url: "#"
            },
            {
                title: "International studies",
                url: "#"
            },
            {
                title: "Law",
                url: "#"
            },
            {
                title: "Management",
                url: "#"
            },
            {
                title: "Nursing and midwifery",
                url: "#"
            }
        ]
    },
    computed: {
        filteredArticles: function() {
            var articles_array = this.articles,
                searchString = this.searchString,
                highlightStr = function(txt, str) {
                    var matchStart = txt
                        .toLowerCase()
                        .indexOf("" + str.toLowerCase() + ""),
                        matchEnd = matchStart + str.length - 1,
                        beforeMatch = txt.slice(0, matchStart),
                        matchText = txt.slice(matchStart, matchEnd + 1),
                        afterMatch = txt.slice(matchEnd + 1);

                    return (
                        beforeMatch + "<strong>" + matchText + "</strong>" + afterMatch
                    );
                };

            if (!searchString) {
                return articles_array;
            }

            searchString = searchString.trim().toLowerCase();

            articles_array = articles_array.filter(function(item) {
                if (item.title.toLowerCase().indexOf(searchString) !== -1) {
                    return {
                        title: highlightStr(item.title, searchString),
                        url: item.url
                    };
                    // return item;
                }
            });

            return articles_array;
        }
    }
});